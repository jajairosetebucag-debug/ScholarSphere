/* StudentHub PH – core helpers, storage adapter, grading scales.
   Everything hangs off window.SH so pages stay plain scripts (no build step). */
(function () {
  'use strict';
  var SH = (window.SH = window.SH || { tools: [], lib: {}, routes: {} });

  SH.addRoute = function (path, def) { SH.routes[path] = def; };
  SH.go = function (path) { location.hash = '#' + path; };

  SH.onLeave = function (f) { (SH._leave = SH._leave || []).push(f); };

  SH.$ = function (s, r) { return (r || document).querySelector(s); };
  SH.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  SH.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  SH.uid = function () { return Math.random().toString(36).slice(2, 10); };
  SH.num = function (v) { var n = parseFloat(v); return isNaN(n) ? null : n; };
  SH.fmt = function (n, d) {
    if (n == null || isNaN(n)) return '—';
    d = d == null ? 2 : d;
    return (Math.round(n * Math.pow(10, d)) / Math.pow(10, d)).toFixed(d);
  };
  SH.ymd = function (d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  };
  SH.today = function () { return SH.ymd(new Date()); };

  SH.toast = function (msg) {
    var t = SH.$('#toast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(SH._tt); SH._tt = setTimeout(function () { t.classList.remove('show'); }, 2600);
  };

  SH.copyRich = function (html, text) {
    function fallback() {
      try { navigator.clipboard.writeText(text).then(function () { SH.toast('Copied'); }, legacy); } catch (e) { legacy(); }
    }
    function legacy() {
      var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); SH.toast('Copied'); } catch (e) { SH.toast('Copy failed – select and copy manually'); }
      document.body.removeChild(ta);
    }
    if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) {
      try {
        navigator.clipboard.write([new ClipboardItem({
          'text/html': new Blob([html], { type: 'text/html' }),
          'text/plain': new Blob([text], { type: 'text/plain' })
        })]).then(function () { SH.toast('Copied (formatting kept)'); }, fallback);
        return;
      } catch (e) { /* fall through */ }
    }
    fallback();
  };

  /* ---------- Storage adapter ----------
     Dev build: localStorage, scoped per user id ("guest" when logged out).
     INTEGRATION: replace get/set with calls to your database API (e.g. Postgres/Supabase/Firebase).
     Keep the same interface so pages do not change. */
  var PFX = 'shph:';
  SH.db = {
    scope: function () { return SH.auth && SH.auth.user() ? SH.auth.user().id : 'guest'; },
    get: function (k, f) {
      try { var v = localStorage.getItem(PFX + this.scope() + ':' + k); return v == null ? f : JSON.parse(v); } catch (e) { return f; }
    },
    set: function (k, v) {
      try { localStorage.setItem(PFX + this.scope() + ':' + k, JSON.stringify(v)); }
      catch (e) { SH.toast('Could not save (storage full or blocked).'); }
    },
    getGlobal: function (k, f) {
      try { var v = localStorage.getItem(PFX + 'global:' + k); return v == null ? f : JSON.parse(v); } catch (e) { return f; }
    },
    setGlobal: function (k, v) { try { localStorage.setItem(PFX + 'global:' + k, JSON.stringify(v)); } catch (e) {} },
    /* copy guest data into a newly created account so nothing is lost on sign-up */
    migrateGuest: function (toId) {
      try {
        Object.keys(localStorage).forEach(function (key) {
          if (key.indexOf(PFX + 'guest:') === 0) {
            localStorage.setItem(PFX + toId + ':' + key.slice((PFX + 'guest:').length), localStorage.getItem(key));
          }
        });
      } catch (e) {}
    }
  };

  SH.history = {
    add: function (type, label, route) {
      var h = SH.db.get('history', []);
      h.unshift({ id: SH.uid(), type: type, label: label, route: route, at: Date.now() });
      SH.db.set('history', h.slice(0, 50));
    },
    list: function () { return SH.db.get('history', []); }
  };

  /* Saved tools (stars) */
  SH.saved = {
    list: function () { return SH.db.get('savedTools', []); },
    has: function (id) { return this.list().indexOf(id) > -1; },
    toggle: function (id) {
      var l = this.list(), i = l.indexOf(id);
      if (i > -1) l.splice(i, 1); else l.push(id);
      SH.db.set('savedTools', l); return i === -1;
    }
  };

  /* Analytics hook. INTEGRATION: send to your analytics provider (privacy-respecting, with consent). */
  SH.track = function (name, props) { /* no-op in dev build */ };

  /* ---------- Grading scales ----------
     rows = [minPercent, gradeLabel], sorted high → low. Philippine schools differ: the PH scale
     below is a SAMPLE and is editable via the "Custom" scale. */
  var SCALES = {
    ph: { id: 'ph', name: 'Philippines 1.00–5.00 (sample – schools vary)', lowerBetter: true,
      rows: [[97, '1.00'], [94, '1.25'], [91, '1.50'], [88, '1.75'], [85, '2.00'], [82, '2.25'], [79, '2.50'], [76, '2.75'], [75, '3.00'], [0, '5.00']] },
    us4: { id: 'us4', name: '4.0 scale (letter-based)', lowerBetter: false,
      rows: [[93, '4.0'], [90, '3.7'], [87, '3.3'], [83, '3.0'], [80, '2.7'], [77, '2.3'], [73, '2.0'], [70, '1.7'], [67, '1.3'], [63, '1.0'], [60, '0.7'], [0, '0.0']] }
  };
  SH.grading = {
    scales: function () {
      var c = SH.db.get('customScale', null);
      var out = { ph: SCALES.ph, us4: SCALES.us4 };
      out.custom = { id: 'custom', name: 'Custom (edit in GPA calculator)', lowerBetter: c ? !!c.lowerBetter : true, rows: c ? c.rows : SCALES.ph.rows.slice() };
      return out;
    },
    get: function (id) { var s = this.scales(); return s[id] || s.ph; },
    saveCustom: function (rows, lowerBetter) { SH.db.set('customScale', { rows: rows, lowerBetter: lowerBetter }); },
    parseRows: function (text) {
      var rows = [];
      String(text || '').split(/\n/).forEach(function (line) {
        var m = line.split(/[,\t;]/); if (m.length < 2) return;
        var min = SH.num(m[0]); var g = m[1].trim();
        if (min != null && g) rows.push([min, g]);
      });
      rows.sort(function (a, b) { return b[0] - a[0]; });
      return rows;
    },
    convert: function (pct, scale) {
      if (pct == null || isNaN(pct)) return null;
      for (var i = 0; i < scale.rows.length; i++) if (pct >= scale.rows[i][0]) return scale.rows[i][1];
      return scale.rows.length ? scale.rows[scale.rows.length - 1][1] : null;
    },
    /* minimum percent needed for a grade label */
    minFor: function (label, scale) {
      for (var i = 0; i < scale.rows.length; i++) if (scale.rows[i][1] === label) return scale.rows[i][0];
      return null;
    }
  };

  /* Page helper: simple reusable page header */
  SH.pageHead = function (title, desc, crumb) {
    return '<div class="page-head"><div class="crumbs">' + (crumb || '') + '</div><h1>' + SH.esc(title) + '</h1><p>' + desc + '</p></div>';
  };
})();
