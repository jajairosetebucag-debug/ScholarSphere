/* Auth service – DEVELOPMENT ADAPTER ONLY.
   Accounts live in this browser's localStorage. This is NOT secure and NOT shared across devices.
   INTEGRATION REQUIRED for production: a real auth provider (e.g. Supabase Auth, Firebase Auth, Auth0, or
   your own backend with hashed passwords server-side) plus an email service for verification and password reset.
   Keep this interface (user, signUp, logIn, logOut, updateProfile, resetPassword) and swap the internals. */
(function () {
  'use strict';
  var SH = window.SH;
  var listeners = [];

  function hash(str) {
    if (window.crypto && crypto.subtle && window.TextEncoder) {
      return crypto.subtle.digest('SHA-256', new TextEncoder().encode(str)).then(function (buf) {
        return Array.prototype.map.call(new Uint8Array(buf), function (b) { return b.toString(16).padStart(2, '0'); }).join('');
      });
    }
    var h = 5381; for (var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return Promise.resolve('weak' + h);
  }
  function users() { return SH.db.getGlobal('users', []); }
  function save(u) { SH.db.setGlobal('users', u); }
  function emit() { listeners.forEach(function (f) { f(); }); }
  function validEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

  SH.auth = {
    isMock: true,
    onChange: function (f) { listeners.push(f); },
    user: function () {
      var id = SH.db.getGlobal('session', null); if (!id) return null;
      var u = users().filter(function (x) { return x.id === id; })[0];
      if (!u) return null;
      return { id: u.id, name: u.name, email: u.email, school: u.school || '', level: u.level || '', plan: u.plan || 'free' };
    },
    signUp: function (name, email, password) {
      name = String(name || '').trim(); email = String(email || '').trim().toLowerCase();
      if (!name) return Promise.reject(new Error('Please enter your name.'));
      if (!validEmail(email)) return Promise.reject(new Error('Please enter a valid email address.'));
      if (String(password || '').length < 8) return Promise.reject(new Error('Password must be at least 8 characters.'));
      if (users().some(function (u) { return u.email === email; })) return Promise.reject(new Error('An account with this email already exists on this device.'));
      var salt = SH.uid() + SH.uid();
      return hash(salt + password).then(function (h) {
        var u = { id: 'u_' + SH.uid(), name: name, email: email, salt: salt, hash: h, plan: 'free', createdAt: Date.now() };
        var all = users(); all.push(u); save(all);
        SH.db.migrateGuest(u.id);
        SH.db.setGlobal('session', u.id);
        emit(); return SH.auth.user();
      });
    },
    logIn: function (email, password) {
      email = String(email || '').trim().toLowerCase();
      var u = users().filter(function (x) { return x.email === email; })[0];
      if (!u) return Promise.reject(new Error('Incorrect email or password.'));
      return hash(u.salt + password).then(function (h) {
        if (h !== u.hash) throw new Error('Incorrect email or password.');
        SH.db.setGlobal('session', u.id); emit(); return SH.auth.user();
      });
    },
    logOut: function () { SH.db.setGlobal('session', null); emit(); },
    updateProfile: function (patch) {
      var cur = SH.auth.user(); if (!cur) return;
      var all = users();
      all.forEach(function (u) {
        if (u.id === cur.id) { ['name', 'school', 'level'].forEach(function (k) { if (patch[k] != null) u[k] = String(patch[k]).trim(); }); }
      });
      save(all); emit();
    },
    /* INTEGRATION: needs an email service. Deliberately not faked in the dev build. */
    resetPassword: function () {
      return Promise.reject(new Error('Password reset needs an email service, which is not connected in this development build.'));
    }
  };
})();
