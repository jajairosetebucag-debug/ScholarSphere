/* Tool registry – single source of truth for navigation, hubs, search and the dashboard.
   To add a tool later: add an entry here, register its route in a page file. */
(function () {
  'use strict';
  var SH = window.SH;
  // status: 'live' (works now) | 'soon' (planned – page explains what is needed)
  SH.tools = [
    { id: 'grade', name: 'Grade Calculator', route: '/grade-calculator', section: 'study', icon: '📊', status: 'live',
      desc: 'Weighted grades, current standing and the score you need to hit your target.', kw: 'grade calculate computer weighted percentage target quiz exam' },
    { id: 'gpa', name: 'GPA Calculator', route: '/gpa-calculator', section: 'study', icon: '🎓', status: 'live',
      desc: 'Units-weighted GPA with Philippine, 4.0 and custom scales.', kw: 'gpa gwa general weighted average units grade scale cumulative' },
    { id: 'planner', name: 'Study Planner', route: '/study-planner', section: 'study', icon: '🗓️', status: 'live',
      desc: 'Subjects, exams, assignments and study sessions in list and calendar views.', kw: 'planner plan schedule study deadline exam assignment calendar organize' },
    { id: 'flashcards', name: 'Reviewer & Flashcards', route: '/flashcards', section: 'study', icon: '🧠', status: 'live',
      desc: 'Make decks by hand or turn your own notes into flashcards and practice questions.', kw: 'flashcards reviewer review notes quiz questions deck memorize study reviewer' },
    { id: 'apa', name: 'APA 7 Citation Generator', route: '/apa-citation-generator', section: 'research', icon: '📚', status: 'live',
      desc: 'Reference entries and in-text citations for books, articles, websites, reports and videos.', kw: 'apa citation cite reference bibliography doi thesis research' },
    { id: 'cv', name: 'CV Builder', route: '/cv-builder', section: 'career', icon: '📄', status: 'live',
      desc: 'Build a clean CV with a live preview and export it as PDF.', kw: 'cv resume curriculum vitae job internship career pdf' },

    { id: 'citecheck', name: 'Citation Checker', route: '/citation-checker', section: 'research', icon: '✅', status: 'soon', phase: 2,
      desc: 'Paste references and spot possible APA formatting issues.', kw: 'apa citation check checker reference format' },
    { id: 'thesis', name: 'Thesis Organizer', route: '/thesis-organizer', section: 'research', icon: '🧪', status: 'soon', phase: 2,
      desc: 'Organize chapters, objectives, literature and deadlines with a progress tracker.', kw: 'thesis research planner organizer chapter objectives methodology' },
    { id: 'outline', name: 'Presentation Outline Generator', route: '/presentation-outline', section: 'research', icon: '🖥️', status: 'soon', phase: 2,
      desc: 'Turn a topic into a structured outline with speaker-note prompts.', kw: 'presentation slides outline defense report speaker notes' },
    { id: 'cover', name: 'Cover Letter Builder', route: '/cover-letter-builder', section: 'career', icon: '✉️', status: 'soon', phase: 2,
      desc: 'Customizable cover letters from your role, skills and experience.', kw: 'cover letter application internship job' },
    { id: 'interview', name: 'Interview Practice', route: '/interview-practice', section: 'career', icon: '🎤', status: 'soon', phase: 2,
      desc: 'Practice questions based on a job or industry.', kw: 'interview practice questions internship job' },
    { id: 'internships', name: 'Internship Finder', route: '/internships', section: 'career', icon: '💼', status: 'soon', phase: 2,
      desc: 'A searchable internship directory with verified listings.', kw: 'internship ojt on the job training intern find' },
    { id: 'scholarships', name: 'Scholarship Finder', route: '/scholarships', section: 'career', icon: '🏅', status: 'soon', phase: 2,
      desc: 'Scholarships for Filipino students with official links and last-verified dates.', kw: 'scholarship scholarships grant funding tuition dost ched' },
    { id: 'templates', name: 'Template Library', route: '/templates', section: 'resources', icon: '🧩', status: 'soon', phase: 2,
      desc: 'Academic, career and productivity templates (free and premium).', kw: 'template templates planner tracker lab report portfolio' },
    { id: 'resources', name: 'Student Resource Directory', route: '/resources', section: 'resources', icon: '🔎', status: 'soon', phase: 2,
      desc: 'Curated free learning sites, research databases and student discounts.', kw: 'resources research apa citation databases free learning discounts library' }
  ];
  SH.toolById = function (id) { return SH.tools.filter(function (t) { return t.id === id; })[0]; };
  SH.toolsIn = function (section) { return SH.tools.filter(function (t) { return t.section === section; }); };

  /* Global search – scoring over name, keywords and description. */
  SH.search = function (q) {
    var toks = String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
    if (!toks.length) return [];
    var out = [];
    SH.tools.forEach(function (t) {
      var name = t.name.toLowerCase(), kw = ' ' + t.kw.toLowerCase() + ' ', desc = t.desc.toLowerCase(), s = 0, hit = 0;
      toks.forEach(function (k) {
        var h = 0;
        if (name.indexOf(k) > -1) h += 5;
        if (kw.indexOf(' ' + k) > -1) h += 3; else if (kw.indexOf(k) > -1) h += 2;
        if (desc.indexOf(k) > -1) h += 1;
        if (h) hit++; s += h;
      });
      if (hit) out.push({ t: t, s: s + hit * 2 + (t.status === 'live' ? 0.5 : 0) });
    });
    out.sort(function (a, b) { return b.s - a.s; });
    return out.slice(0, 6).map(function (x) { return x.t; });
  };

  /* Reusable tool card (with save-to-dashboard star) */
  SH.toolCard = function (t) {
    var star = t.status === 'live'
      ? '<button class="star" data-star="' + t.id + '" aria-pressed="' + SH.saved.has(t.id) + '" aria-label="Save ' + SH.esc(t.name) + ' to my dashboard" title="Save to dashboard">★</button>' : '';
    return '<div class="card tool"><a href="#' + t.route + '" style="text-decoration:none;color:inherit;display:flex;flex-direction:column;gap:6px">' +
      '<span class="ic" aria-hidden="true">' + t.icon + '</span><h3>' + SH.esc(t.name) + '</h3><p>' + SH.esc(t.desc) + '</p>' +
      '<span><span class="tag ' + (t.status === 'live' ? '' : 'soon') + '">' + (t.status === 'live' ? 'Free · Available now' : 'Coming in Phase ' + t.phase) + '</span></span></a>' + star + '</div>';
  };
  /* one-time delegated handler for stars */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-star]');
    if (!b) return;
    var on = SH.saved.toggle(b.getAttribute('data-star'));
    b.setAttribute('aria-pressed', on);
    SH.toast(on ? 'Saved to your dashboard' : 'Removed from saved tools');
  });
})();
