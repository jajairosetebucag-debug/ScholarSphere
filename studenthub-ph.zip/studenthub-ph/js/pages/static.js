/* Legal/trust pages, contact, and "coming soon" pages for Phase 2/3 tools. */
(function () {
  'use strict';
  var SH = window.SH, e = SH.esc;

  var DRAFT = '<div class="notice"><strong>Draft template.</strong> This text describes the intended behavior of StudentHub PH. Have it reviewed by a qualified lawyer (including Data Privacy Act of 2012 / RA 10173 requirements) before launching publicly.</div>';
  function legal(path, title, desc, body) {
    SH.addRoute(path, { title: title + ' | StudentHub PH', desc: desc, render: function (root) {
      root.innerHTML = '<div class="wrap section"><div class="prose"><h1>' + title + '</h1><p class="muted">Last updated: placeholder – set on publication.</p>' + DRAFT + body + '</div></div>';
    } });
  }

  legal('/privacy', 'Privacy Policy', 'How StudentHub PH handles your data.',
    '<h2>What we collect</h2><p>Account details you give us (name, email, optional school and level) and the content you create in the tools (planner items, flashcards, citations, CV drafts).</p>' +
    '<h2>How it is used</h2><p>To run the tools you use and improve them. We do not sell personal student information.</p>' +
    '<h2>Where data is stored</h2><p>In this development build, data is stored only in your browser. A production version will store it in a hosted database; this policy must be updated to name the providers and regions used.</p>' +
    '<h2>Your choices</h2><p>You can edit or delete your content at any time. Account deletion and data export require the production backend.</p>' +
    '<h2>Contact</h2><p>See the <a href="#/contact">Contact page</a>.</p>');
  legal('/terms', 'Terms of Service', 'Terms for using StudentHub PH.',
    '<h2>Use of the service</h2><p>StudentHub PH provides study and career tools for personal, educational use. Do not misuse the service or attempt to disrupt it.</p>' +
    '<h2>Academic integrity</h2><p>Tools are study aids. You are responsible for following your school’s academic-integrity policy and for verifying any generated content.</p>' +
    '<h2>Paid plans</h2><p>Pricing may change. Billing terms will be added when paid plans launch.</p>' +
    '<h2>No warranty</h2><p>Calculators and generators may contain errors. Confirm important results with your school or official sources.</p>');
  legal('/cookies', 'Cookie Policy', 'How StudentHub PH uses cookies and local storage.',
    '<h2>What we use</h2><p>This build uses your browser’s local storage to save your work and session. It does not set advertising or analytics cookies.</p>' +
    '<h2>Future changes</h2><p>If analytics or advertising are added, this policy and a consent banner must be updated first.</p>');
  legal('/disclaimer', 'Disclaimer', 'Important notes about StudentHub PH tools.',
    '<h2>Educational aids only</h2><p>Grade and GPA results depend on your school’s own rules; scales shown are samples. Citation output should be checked against official APA guidance. Generated study material is derived from the text you provide and may be incomplete or wrong – verify it.</p>' +
    '<h2>Not professional advice</h2><p>Nothing here is legal, financial or academic-advising advice.</p>');

  var MAIL = 'hello@studenthub.example'; // PLACEHOLDER – replace with a real address
  SH.addRoute('/contact', { title: 'Contact | StudentHub PH', desc: 'Contact StudentHub PH.', render: function (root) {
    root.innerHTML = '<div class="wrap section"><div class="prose"><h1>Contact</h1><div class="notice">Placeholder address – replace <code>' + MAIL + '</code> with a real inbox. A contact form needs an email/backend integration.</div><p>Email: <a href="mailto:' + MAIL + '">' + MAIL + '</a></p></div></div>';
  } });
  SH.addRoute('/report-issue', { title: 'Report an issue | StudentHub PH', desc: 'Report a bug, wrong information or inappropriate content.', render: function (root) {
    root.innerHTML = '<div class="wrap section"><div class="prose"><h1>Report an issue</h1><div class="notice">Reports are sent by email for now. An in-app report queue for the admin dashboard needs a backend (Phase 2).</div><p>Describe the page, what you expected and what happened, then email <a href="mailto:' + MAIL + '?subject=StudentHub%20PH%20issue">' + MAIL + '</a>.</p></div></div>';
  } });

  /* Coming-soon pages – honest about what each needs */
  var NEEDS = {
    citecheck: 'A rules engine for APA checks (can be built client-side).',
    thesis: 'Saved projects in a database (account backend).',
    outline: 'An AI model integration for outline and speaker-note generation.',
    cover: 'An AI model integration (optional) plus saved profiles.',
    interview: 'A question bank by industry (content) and optionally an AI model.',
    internships: 'A real, verified data source and an admin tool to add listings; we will not invent listings.',
    scholarships: 'Verified listings with official links and a “last verified” date for each; we will not invent scholarship information.',
    templates: 'A template catalog, file storage and payments for premium templates.',
    resources: 'A curated, categorized resource database and admin tool.'
  };
  SH.tools.filter(function (t) { return t.status === 'soon'; }).forEach(function (t) {
    SH.addRoute(t.route, { title: t.name + ' (coming soon) | StudentHub PH', desc: t.desc, render: function (root) {
      root.innerHTML = '<div class="wrap">' + SH.pageHead(t.name, e(t.desc), '<a href="#/">Home</a>') +
        '<div class="card" style="max-width:640px"><span class="tag soon">Coming in Phase ' + t.phase + '</span><h2 style="margin-top:10px">Not available yet</h2>' +
        '<p>We’re building the core tools first (grade &amp; GPA calculators, APA 7, planner, flashcards, CV). This tool comes next.</p>' +
        '<p class="small muted"><strong>Integration needed:</strong> ' + e(NEEDS[t.id] || 'To be defined.') + '</p><a class="btn btn-primary" href="#/">Explore available tools</a></div></div>';
    } });
  });
})();
