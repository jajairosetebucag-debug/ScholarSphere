/* Study Planner – subjects, exams, assignments, study sessions; list + calendar views */
(function () {
  'use strict';
  var SH = window.SH;
  var TYPES = { exam: 'Exam', assignment: 'Assignment', study: 'Study session', task: 'Task' };
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  SH.addRoute('/study-planner', {
    title: 'Student Planner Philippines – Study Planner for Exams & Deadlines | StudentHub PH',
    desc: 'Free student planner for Filipino students. Add subjects, exams, assignments and study sessions, then track deadlines in list or calendar view.',
    render: function (root) {
      var items = SH.db.get('plan', []), subjects = SH.db.get('subjects', []);
      var view = 'list', filter = 'all', cal = new Date(), sel = SH.today();
      cal.setDate(1);

      root.innerHTML = '<div class="wrap">' + SH.pageHead('Study Planner', 'Keep track of exams, assignments and study sessions in one place.', '<a href="#/study-tools">Study Tools</a> › Study Planner') +
        '<div class="split"><div><div class="tabs" role="tablist"><button class="tab" role="tab" data-v="list">List</button><button class="tab" role="tab" data-v="cal">Calendar</button></div>' +
        '<div id="filters" class="tabs"></div><div id="view"></div></div>' +
        '<div><form class="card" id="f"><h2>Add item</h2><div class="field"><label for="type">Type</label><select id="type">' +
        Object.keys(TYPES).map(function (k) { return '<option value="' + k + '">' + TYPES[k] + '</option>'; }).join('') + '</select></div>' +
        '<div class="field"><label for="title">Title</label><input id="title" required placeholder="e.g. Midterm – Plant Physiology"></div>' +
        '<div class="field"><label for="subject">Subject</label><select id="subject"></select></div>' +
        '<div class="row c2"><div class="field"><label for="date">Date / deadline</label><input id="date" type="date"></div><div class="field"><label for="time">Time (optional)</label><input id="time" type="time"></div></div>' +
        '<button class="btn btn-primary" type="submit">Add to planner</button></form>' +
        '<div class="card" style="margin-top:16px"><h3>Subjects</h3><div class="btn-row" id="chips" style="margin-bottom:10px"></div>' +
        '<form id="sf" class="btn-row" style="flex-wrap:nowrap"><input id="sname" placeholder="New subject" aria-label="New subject name"><button class="btn" type="submit">Add</button></form></div></div></div></div>';

      var viewEl = SH.$('#view', root), subSel = SH.$('#subject', root);
      function save() { SH.db.set('plan', items); SH.db.set('subjects', subjects); }
      function drawSubjects() {
        subSel.innerHTML = '<option value="">— none —</option>' + subjects.map(function (s) { return '<option>' + SH.esc(s) + '</option>'; }).join('');
        SH.$('#chips', root).innerHTML = subjects.length ? subjects.map(function (s) {
          return '<span class="tag" style="padding:7px 12px">' + SH.esc(s) + ' <button data-rs="' + SH.esc(s) + '" aria-label="Remove ' + SH.esc(s) + '" style="border:0;background:none;cursor:pointer;min-width:24px">✕</button></span>';
        }).join('') : '<span class="small muted">No subjects yet.</span>';
        SH.$('#filters', root).innerHTML = [['all', 'All'], ['open', 'To do'], ['done', 'Done']].concat(Object.keys(TYPES).map(function (k) { return [k, TYPES[k]]; }))
          .map(function (f) { return '<button class="tab" data-f="' + f[0] + '" aria-selected="' + (f[0] === filter) + '">' + f[1] + '</button>'; }).join('');
        SH.$$('[data-v]', root).forEach(function (b) { b.setAttribute('aria-selected', b.dataset.v === view); });
      }
      function passes(i) {
        if (filter === 'all') return true; if (filter === 'open') return !i.done; if (filter === 'done') return i.done; return i.type === filter;
      }
      function itemHtml(i) {
        return '<div class="item' + (i.done ? ' done' : '') + '" data-id="' + i.id + '"><input type="checkbox" data-done ' + (i.done ? 'checked' : '') + ' aria-label="Mark complete: ' + SH.esc(i.title) + '">' +
          '<div style="flex:1"><div class="t">' + SH.esc(i.title) + '</div><div class="meta">' + TYPES[i.type] + (i.subject ? ' · ' + SH.esc(i.subject) : '') +
          (i.date ? ' · ' + SH.esc(i.date) + (i.time ? ' ' + SH.esc(i.time) : '') : '') + '</div></div><button class="xbtn" data-del aria-label="Delete ' + SH.esc(i.title) + '" style="height:38px;width:38px">✕</button></div>';
      }
      function drawList() {
        var t = SH.today(), g = { 'Overdue': [], 'Today': [], 'Upcoming': [], 'No date': [], 'Completed': [] };
        items.filter(passes).sort(function (a, b) { return (a.date || '9999') + (a.time || '') < (b.date || '9999') + (b.time || '') ? -1 : 1; }).forEach(function (i) {
          if (i.done) g.Completed.push(i); else if (!i.date) g['No date'].push(i); else if (i.date < t) g.Overdue.push(i); else if (i.date === t) g.Today.push(i); else g.Upcoming.push(i);
        });
        var html = Object.keys(g).filter(function (k) { return g[k].length; }).map(function (k) { return '<h3 style="margin-top:14px">' + k + ' <span class="muted small">(' + g[k].length + ')</span></h3>' + g[k].map(itemHtml).join(''); }).join('');
        viewEl.innerHTML = html || '<div class="card center muted">Nothing here yet. Add your first exam, assignment or study session →</div>';
      }
      function drawCal() {
        var y = cal.getFullYear(), m = cal.getMonth(), first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate(), t = SH.today(), cells = '';
        ['S', 'M', 'T', 'W', 'T', 'F', 'S'].forEach(function (d) { cells += '<div class="dow">' + d + '</div>'; });
        for (var b = 0; b < first; b++) cells += '<div></div>';
        for (var d = 1; d <= days; d++) {
          var ds = y + '-' + String(m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
          var its = items.filter(function (i) { return i.date === ds && passes(i); });
          cells += '<button data-d="' + ds + '" class="' + (ds === sel ? 'sel ' : '') + (ds === t ? 'today' : '') + '" aria-label="' + ds + ', ' + its.length + ' items">' + d +
            '<span class="dots">' + its.slice(0, 4).map(function (i) { return '<i class="' + i.type + '"></i>'; }).join('') + '</span></button>';
        }
        var dayItems = items.filter(function (i) { return i.date === sel && passes(i); });
        viewEl.innerHTML = '<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">' +
          '<button class="btn btn-sm" data-m="-1" aria-label="Previous month">‹</button><strong>' + MONTHS[m] + ' ' + y + '</strong><button class="btn btn-sm" data-m="1" aria-label="Next month">›</button></div>' +
          '<div class="cal">' + cells + '</div><p class="small muted">● exam (red) · assignment (orange) · study session (green)</p></div>' +
          '<h3 style="margin-top:14px">' + sel + '</h3>' + (dayItems.map(itemHtml).join('') || '<p class="muted small">No items on this day.</p>');
      }
      function draw() { drawSubjects(); if (view === 'list') drawList(); else drawCal(); }

      root.addEventListener('click', function (e) {
        var t;
        if ((t = e.target.closest('[data-v]'))) { view = t.dataset.v; draw(); }
        else if ((t = e.target.closest('[data-f]'))) { filter = t.dataset.f; draw(); }
        else if ((t = e.target.closest('[data-d]'))) { sel = t.dataset.d; drawCal(); }
        else if ((t = e.target.closest('[data-m]'))) { cal.setMonth(cal.getMonth() + parseInt(t.dataset.m, 10)); drawCal(); }
        else if ((t = e.target.closest('[data-rs]'))) { subjects = subjects.filter(function (s) { return s !== t.dataset.rs; }); save(); draw(); }
        else if ((t = e.target.closest('[data-del]'))) { var id = t.closest('.item').dataset.id; items = items.filter(function (i) { return i.id !== id; }); save(); draw(); }
      });
      root.addEventListener('change', function (e) {
        if (!e.target.matches('[data-done]')) return;
        var id = e.target.closest('.item').dataset.id;
        items.forEach(function (i) { if (i.id === id) i.done = e.target.checked; }); save(); draw();
      });
      SH.$('#f', root).addEventListener('submit', function (e) {
        e.preventDefault();
        var title = SH.$('#title', root).value.trim(); if (!title) return;
        items.push({ id: SH.uid(), type: SH.$('#type', root).value, title: title, subject: subSel.value, date: SH.$('#date', root).value, time: SH.$('#time', root).value, done: false });
        save(); SH.$('#title', root).value = ''; SH.toast('Added'); draw();
      });
      SH.$('#sf', root).addEventListener('submit', function (e) {
        e.preventDefault();
        var n = SH.$('#sname', root).value.trim(); if (!n || subjects.indexOf(n) > -1) return;
        subjects.push(n); SH.$('#sname', root).value = ''; save(); draw();
      });
      draw();
    }
  });
})();
