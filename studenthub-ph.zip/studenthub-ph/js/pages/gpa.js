/* GPA Calculator – units-weighted average, Philippine / 4.0 / custom scales */
(function () {
  'use strict';
  var SH = window.SH;

  SH.lib.gpaCalc = function (subjects) {
    var pts = 0, units = 0;
    subjects.forEach(function (s) {
      var u = SH.num(s.units), g = SH.num(s.grade);
      if (u != null && u > 0 && g != null) { pts += u * g; units += u; }
    });
    return { gpa: units > 0 ? pts / units : null, units: units };
  };

  SH.addRoute('/gpa-calculator', {
    title: 'GPA Calculator Philippines – GWA with Units & Custom Scales | StudentHub PH',
    desc: 'Free GPA / GWA calculator for Filipino students. Add subjects, units and grades, use the 1.00–5.00 scale, a 4.0 scale or your own custom scale.',
    render: function (root) {
      var st = SH.db.get('gpa', null) || { scale: 'ph', subjects: [{ id: SH.uid(), name: '', units: '3', grade: '' }, { id: SH.uid(), name: '', units: '3', grade: '' }] };
      root.innerHTML = '<div class="wrap">' + SH.pageHead('GPA Calculator',
        'Your GPA (or GWA) is the average of your grades weighted by units. Enter the grade exactly as it appears on your grade sheet.',
        '<a href="#/study-tools">Study Tools</a> › GPA Calculator') +
        '<div class="split"><div class="card"><div class="field"><label for="scale">Grading scale</label><select id="scale"></select></div>' +
        '<p class="small muted" id="hint"></p><div class="rows" id="rows"></div>' +
        '<div class="btn-row" style="margin-top:12px"><button class="btn btn-sm" id="add">+ Add subject</button><button class="btn btn-sm" id="clear">Clear</button></div></div>' +
        '<div><div class="card" id="out" aria-live="polite"></div>' +
        '<div class="card" style="margin-top:16px"><h3>Percentage → grade converter</h3><div class="row c2"><div class="field"><label for="pct">Percentage</label><input id="pct" inputmode="decimal" placeholder="e.g. 88"></div>' +
        '<div class="field"><label>Equivalent</label><div class="big" id="conv" style="font-size:1.6rem">—</div></div></div></div>' +
        '<details class="card" style="margin-top:16px"><summary>Edit custom scale</summary><p class="small muted">One row per line: <code>minimum percent, grade</code> (highest first). Used when you pick “Custom”.</p>' +
        '<textarea id="custom" aria-label="Custom scale rows"></textarea><label style="margin-top:8px"><input type="checkbox" id="lower" style="width:auto;min-height:0"> Lower numbers are better (like 1.00 = highest)</label>' +
        '<button class="btn btn-sm" id="savecustom" style="margin-top:8px">Save custom scale</button></details></div></div>' +
        '<div class="prose section"><h2>Using the Philippine scale</h2><p>Many Philippine universities use 1.00 (highest) to 5.00 (failing), with 3.00 as the passing mark. The conversion table here is a <strong>sample</strong>; use the custom scale to match your school’s official table.</p></div></div>';

      var rows = SH.$('#rows', root), out = SH.$('#out', root), scaleSel = SH.$('#scale', root);
      function save() { SH.db.set('gpa', st); }
      function drawScale() {
        var sc = SH.grading.scales();
        scaleSel.innerHTML = Object.keys(sc).map(function (k) { return '<option value="' + k + '"' + (k === st.scale ? ' selected' : '') + '>' + SH.esc(sc[k].name) + '</option>'; }).join('');
        var s = sc[st.scale];
        SH.$('#hint', root).textContent = s.lowerBetter ? 'On this scale, a lower number is a better grade.' : 'On this scale, a higher number is a better grade.';
        SH.$('#custom', root).value = sc.custom.rows.map(function (r) { return r[0] + ', ' + r[1]; }).join('\n');
        SH.$('#lower', root).checked = sc.custom.lowerBetter;
      }
      function drawRows() {
        rows.innerHTML = st.subjects.map(function (s) {
          return '<div class="erow gpa" data-id="' + s.id + '"><div><label>Subject</label><input data-f="name" value="' + SH.esc(s.name) + '" placeholder="Optional"></div>' +
            '<div><label>Units</label><input data-f="units" inputmode="decimal" value="' + SH.esc(s.units) + '"></div>' +
            '<div><label>Grade</label><input data-f="grade" inputmode="decimal" value="' + SH.esc(s.grade) + '" placeholder="e.g. 1.75"></div>' +
            '<button class="xbtn" data-del aria-label="Remove subject">✕</button></div>';
        }).join('');
      }
      function calc() {
        var r = SH.lib.gpaCalc(st.subjects), sc = SH.grading.get(st.scale);
        out.innerHTML = '<h2>Result</h2><div class="stat"><div class="lbl">GPA / GWA</div><div class="big">' + (r.gpa == null ? '—' : SH.fmt(r.gpa, 2)) + '</div>' +
          '<div class="small muted">' + SH.fmt(r.units, 1) + ' total units · ' + (sc.lowerBetter ? 'lower is better' : 'higher is better') + '</div></div>' +
          '<p class="small muted" style="margin-top:12px">Rounding and honors rules differ by school. Check your registrar’s official computation.</p>' +
          '<button class="btn btn-sm" id="savehist">Save to history</button>';
        SH.$('#savehist', out).addEventListener('click', function () { SH.history.add('gpa', 'GPA calculation: ' + (r.gpa == null ? '—' : SH.fmt(r.gpa, 2)), '/gpa-calculator'); SH.toast('Saved to history'); });
        save();
      }
      rows.addEventListener('input', function (e) {
        var row = e.target.closest('.erow'); if (!row) return;
        st.subjects.filter(function (x) { return x.id === row.dataset.id; })[0][e.target.dataset.f] = e.target.value; calc();
      });
      rows.addEventListener('click', function (e) {
        if (!e.target.closest('[data-del]')) return;
        var id = e.target.closest('.erow').dataset.id; st.subjects = st.subjects.filter(function (x) { return x.id !== id; }); drawRows(); calc();
      });
      SH.$('#add', root).addEventListener('click', function () { st.subjects.push({ id: SH.uid(), name: '', units: '3', grade: '' }); drawRows(); calc(); });
      SH.$('#clear', root).addEventListener('click', function () { st.subjects = [{ id: SH.uid(), name: '', units: '3', grade: '' }]; drawRows(); calc(); });
      scaleSel.addEventListener('change', function () { st.scale = scaleSel.value; drawScale(); calc(); convert(); });
      SH.$('#savecustom', root).addEventListener('click', function () {
        var r = SH.grading.parseRows(SH.$('#custom', root).value);
        if (!r.length) { SH.toast('Add at least one row like “75, 3.00”'); return; }
        SH.grading.saveCustom(r, SH.$('#lower', root).checked); st.scale = 'custom'; drawScale(); calc(); SH.toast('Custom scale saved');
      });
      function convert() {
        var v = SH.num(SH.$('#pct', root).value), g = SH.grading.convert(v, SH.grading.get(st.scale));
        SH.$('#conv', root).textContent = g == null ? '—' : g;
      }
      SH.$('#pct', root).addEventListener('input', convert);
      drawScale(); drawRows(); calc();
    }
  });
})();
