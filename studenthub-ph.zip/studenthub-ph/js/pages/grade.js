/* Grade Calculator – weighted components, current grade, required score for a target grade */
(function () {
  'use strict';
  var SH = window.SH;

  function defaults() {
    return {
      scale: 'ph', target: '2.00',
      comps: [['Activities', 20], ['Quizzes', 20], ['Exams', 40], ['Projects', 10], ['Attendance', 5], ['Other', 5]]
        .map(function (c) { return { id: SH.uid(), name: c[0], weight: c[1], score: '' }; })
    };
  }

  /* pure calculation (also used by tests) */
  SH.lib.gradeCalc = function (comps, targetPct) {
    var earned = 0, gradedW = 0, totalW = 0;
    comps.forEach(function (c) {
      var w = SH.num(c.weight) || 0, s = SH.num(c.score);
      totalW += w;
      if (s != null) { earned += w * s / 100; gradedW += w; }
    });
    var remW = totalW - gradedW;
    return {
      totalW: totalW, gradedW: gradedW, remW: remW, earned: earned,
      current: gradedW > 0 ? earned / gradedW * 100 : null,
      finalIfDone: remW <= 0.0001 && totalW > 0 ? earned / totalW * 100 : null,
      required: remW > 0.0001 && targetPct != null ? (targetPct - earned) / remW * 100 : null
    };
  };

  SH.addRoute('/grade-calculator', {
    title: 'Grade Calculator Philippines – Weighted Grade & Target Score | StudentHub PH',
    desc: 'Free grade calculator for Filipino students. Enter activities, quizzes, exams and projects with custom weights to see your grade and the score you need to reach your target.',
    render: function (root) {
      var st = SH.db.get('grade', null) || defaults();
      root.innerHTML = '<div class="wrap">' + SH.pageHead('Grade Calculator',
        'Enter each component’s weight and your score (as a percentage). Leave the score blank for components you haven’t taken yet to see what you still need.',
        '<a href="#/study-tools">Study Tools</a> › Grade Calculator') +
        '<div class="split"><div class="card"><div class="rows" id="rows"></div>' +
        '<div class="btn-row" style="margin-top:12px"><button class="btn btn-sm" id="add">+ Add component</button><button class="btn btn-sm" id="reset">Reset</button></div>' +
        '<div class="row c2" style="margin-top:16px"><div class="field"><label for="scale">Grading scale</label><select id="scale"></select></div>' +
        '<div class="field"><label for="target">Target grade</label><select id="target"></select></div></div>' +
        '<p class="small muted">Weights should add up to 100%. Scales differ by school – confirm with your syllabus. Edit the custom scale in the <a href="#/gpa-calculator">GPA calculator</a>.</p></div>' +
        '<div class="card" id="out" aria-live="polite"></div></div>' +
        '<div class="prose section"><h2>How this calculator works</h2><p>Each component contributes <em>weight × score</em> to your grade. Your <strong>current grade</strong> is based only on the components you have scores for. The <strong>required score</strong> is the average you need on the remaining components to reach the minimum percentage of your target grade.</p></div></div>';

      var rows = SH.$('#rows', root), out = SH.$('#out', root), scaleSel = SH.$('#scale', root), tgt = SH.$('#target', root);
      function save() { SH.db.set('grade', st); }
      function drawScale() {
        var sc = SH.grading.scales();
        scaleSel.innerHTML = Object.keys(sc).map(function (k) { return '<option value="' + k + '"' + (k === st.scale ? ' selected' : '') + '>' + SH.esc(sc[k].name) + '</option>'; }).join('');
        var s = sc[st.scale];
        if (!s.rows.some(function (r) { return r[1] === st.target; })) st.target = s.rows[Math.min(4, s.rows.length - 1)][1];
        tgt.innerHTML = s.rows.map(function (r) { return '<option value="' + SH.esc(r[1]) + '"' + (r[1] === st.target ? ' selected' : '') + '>' + SH.esc(r[1]) + ' (≥ ' + r[0] + '%)</option>'; }).join('');
      }
      function drawRows() {
        rows.innerHTML = st.comps.map(function (c) {
          return '<div class="erow" data-id="' + c.id + '"><div><label>Component</label><input data-f="name" value="' + SH.esc(c.name) + '" aria-label="Component name"></div>' +
            '<div><label>Weight %</label><input data-f="weight" inputmode="decimal" value="' + SH.esc(c.weight) + '"></div>' +
            '<div><label>Score %</label><input data-f="score" inputmode="decimal" placeholder="—" value="' + SH.esc(c.score) + '"></div>' +
            '<button class="xbtn" data-del aria-label="Remove ' + SH.esc(c.name) + '">✕</button></div>';
        }).join('');
      }
      function calc() {
        var sc = SH.grading.get(st.scale), tpct = SH.grading.minFor(st.target, sc);
        var r = SH.lib.gradeCalc(st.comps, tpct), warn = '';
        if (Math.abs(r.totalW - 100) > 0.01) warn = '<div class="notice">Weights add up to ' + SH.fmt(r.totalW, 1) + '%, not 100%. Results are scaled to the weights you entered.</div>';
        var curG = SH.grading.convert(r.current, sc), req = '';
        if (r.remW > 0.0001 && r.totalW > 0) {
          if (r.required == null) req = '';
          else if (r.required > 100) req = '<div class="notice">A <strong>' + SH.esc(st.target) + '</strong> is not reachable with the remaining ' + SH.fmt(r.remW, 1) + '% – you would need ' + SH.fmt(r.required, 1) + '%.</div>';
          else if (r.required <= 0) req = '<div class="stat"><div class="lbl">Target secured</div><div>You already have enough points for <strong>' + SH.esc(st.target) + '</strong>.</div></div>';
          else req = '<div class="stat"><div class="lbl">Required average on remaining ' + SH.fmt(r.remW, 1) + '%</div><div class="big">' + SH.fmt(r.required, 1) + '%</div><div class="small">to reach ' + SH.esc(st.target) + ' (≥ ' + tpct + '%)</div></div>';
        }
        var fin = r.finalIfDone != null ? '<div class="stat"><div class="lbl">Final grade</div><div class="big">' + SH.fmt(r.finalIfDone, 2) + '%</div><div>Equivalent: <strong>' + SH.esc(SH.grading.convert(r.finalIfDone, sc)) + '</strong></div></div>' : '';
        out.innerHTML = '<h2>Results</h2>' + warn +
          '<div class="stat" style="margin-bottom:12px"><div class="lbl">Current grade (graded components only)</div><div class="big">' + (r.current == null ? '—' : SH.fmt(r.current, 2) + '%') + '</div>' +
          (curG ? '<div>Equivalent: <strong>' + SH.esc(curG) + '</strong></div>' : '') +
          '<div class="small muted">' + SH.fmt(r.earned, 2) + ' of ' + SH.fmt(r.gradedW, 1) + ' graded points</div></div>' +
          (fin ? fin + '<div style="height:12px"></div>' : '') + req +
          '<div class="btn-row" style="margin-top:14px"><button class="btn btn-sm" id="savehist">Save result to history</button></div>';
        SH.$('#savehist', out).addEventListener('click', function () {
          SH.history.add('grade', 'Grade calculation: ' + (r.current == null ? 'no scores yet' : SH.fmt(r.current, 1) + '%'), '/grade-calculator'); SH.toast('Saved to history');
        });
        save();
      }
      rows.addEventListener('input', function (e) {
        var row = e.target.closest('.erow'); if (!row) return;
        var c = st.comps.filter(function (x) { return x.id === row.dataset.id; })[0];
        c[e.target.dataset.f] = e.target.value; calc();
      });
      rows.addEventListener('click', function (e) {
        if (!e.target.closest('[data-del]')) return;
        var id = e.target.closest('.erow').dataset.id;
        st.comps = st.comps.filter(function (x) { return x.id !== id; }); drawRows(); calc();
      });
      SH.$('#add', root).addEventListener('click', function () { st.comps.push({ id: SH.uid(), name: 'New component', weight: 0, score: '' }); drawRows(); calc(); });
      SH.$('#reset', root).addEventListener('click', function () { st = defaults(); drawScale(); drawRows(); calc(); });
      scaleSel.addEventListener('change', function () { st.scale = scaleSel.value; drawScale(); calc(); });
      tgt.addEventListener('change', function () { st.target = tgt.value; calc(); });
      drawScale(); drawRows(); calc();
    }
  });
})();
