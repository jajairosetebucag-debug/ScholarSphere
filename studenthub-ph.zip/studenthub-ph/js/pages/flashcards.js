/* Reviewer & Flashcards.
   - Manual decks + study mode: fully functional.
   - "Generate from notes": RULE-BASED (no AI). It finds "Term: definition" style lines and definition sentences in the
     student's own notes. INTEGRATION: replace SH.lib.generateFromNotes with a call to an AI model API for smarter output. */
(function () {
  'use strict';
  var SH = window.SH;

  /* Extract term/definition pairs from the student's own text */
  SH.lib.extractPairs = function (text) {
    var pairs = [], seen = {};
    function add(t, d) {
      t = t.replace(/^[\s\-•*\d.)]+/, '').trim(); d = d.trim();
      if (t.length < 2 || t.length > 70 || d.length < 8) return;
      var k = t.toLowerCase(); if (seen[k]) return; seen[k] = 1; pairs.push({ q: t, a: d.replace(/\.$/, '') });
    }
    String(text || '').split(/\n+/).forEach(function (line) {
      var m = line.match(/^\s*[-•*\d.)]*\s*([^:–—-]{2,70}?)\s*[:–—]\s+(.{8,})$/) || line.match(/^\s*[-•*]*\s*([^:]{2,60}?)\s+-\s+(.{8,})$/);
      if (m) { add(m[1], m[2]); return; }
      line.split(/(?<=[.!?])\s+/).forEach(function (s) {
        var d = s.match(/^([A-Z][^,.;:]{1,60}?)\s+(?:is defined as|is called|refers to|is known as|means)\s+(.{8,})$/);
        if (d) add(d[1], d[2]);
        else { var d2 = s.match(/^([A-Z][^,.;:]{1,50}?)\s+(?:is|are)\s+((?:a|an|the)\s+.{10,})$/); if (d2) add(d2[1], d2[2]); }
      });
    });
    return pairs;
  };

  SH.lib.generateFromNotes = function (text) {
    var pairs = SH.lib.extractPairs(text);
    var mcq = [];
    if (pairs.length >= 4) {
      pairs.forEach(function (p, i) {
        var others = pairs.filter(function (_, j) { return j !== i; }).sort(function () { return Math.random() - 0.5; }).slice(0, 3);
        var opts = others.map(function (o) { return o.a; }).concat(p.a).sort(function () { return Math.random() - 0.5; });
        mcq.push({ q: 'Which statement best describes “' + p.q + '”?', opts: opts, ans: opts.indexOf(p.a) });
      });
    }
    return {
      cards: pairs,
      concepts: pairs.map(function (p) { return p.q; }),
      shortAnswer: pairs.map(function (p) { return 'In your own words, explain: ' + p.q + '.'; }),
      mcq: mcq
    };
  };

  SH.addRoute('/flashcards', {
    title: 'Flashcard & Reviewer Maker – Study Notes into Practice | StudentHub PH',
    desc: 'Make flashcard decks by subject, study them with a simple flip interface, and turn your own notes into key concepts, flashcards and practice questions.',
    render: function (root) {
      var decks = SH.db.get('decks', []), tab = 'decks', activeId = decks.length ? decks[0].id : null, study = null, gen = null;
      function save() { SH.db.set('decks', decks); }
      function deck() { return decks.filter(function (d) { return d.id === activeId; })[0]; }

      root.innerHTML = '<div class="wrap">' + SH.pageHead('Reviewer & Flashcards', 'Build subject decks, study with flip cards, or generate a reviewer from your own notes.', '<a href="#/study-tools">Study Tools</a> › Reviewer & Flashcards') +
        '<div class="notice info"><strong>Study aid, not an answer key.</strong> Use this to learn your material. Generated content comes from rules applied to the text you provide and can be incomplete – verify it against your notes and textbook, and follow your school’s academic-integrity policy.</div>' +
        '<div class="tabs" role="tablist"><button class="tab" data-tab="decks">My decks</button><button class="tab" data-tab="gen">Generate from notes</button></div><div id="panel"></div></div>';
      var panel = SH.$('#panel', root);

      function drawTabs() { SH.$$('[data-tab]', root).forEach(function (b) { b.setAttribute('aria-selected', b.dataset.tab === tab); }); }

      function drawDecks() {
        var d = deck();
        panel.innerHTML = '<div class="split"><div class="card"><h2>Decks</h2><div class="btn-row" style="margin-bottom:12px">' +
          decks.map(function (x) { return '<button class="chip" data-deck="' + x.id + '" aria-pressed="' + (x.id === activeId) + '" style="' + (x.id === activeId ? 'background:var(--ind);color:#fff' : '') + '">' + SH.esc(x.name) + ' (' + x.cards.length + ')</button>'; }).join('') +
          '</div><form id="nd" class="btn-row" style="flex-wrap:nowrap"><input id="dn" placeholder="New deck name (e.g. Botany 101)" aria-label="New deck name"><button class="btn" type="submit">Create</button></form>' +
          (d ? '<hr style="border:0;border-top:1px solid var(--line);margin:16px 0"><h3>Add card to “' + SH.esc(d.name) + '”</h3><form id="nc"><div class="field"><label for="cq">Front (question / term)</label><input id="cq" required></div>' +
            '<div class="field"><label for="ca">Back (answer)</label><textarea id="ca" required style="min-height:80px"></textarea></div><button class="btn btn-primary" type="submit">Add card</button></form>' : '') +
          '</div><div class="card">' + (d ? '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><h2 style="margin:0">' + SH.esc(d.name) + '</h2><div class="btn-row"><button class="btn btn-primary btn-sm" id="study"' + (d.cards.length ? '' : ' disabled') + '>Study</button><button class="btn btn-sm btn-danger" id="deldeck">Delete deck</button></div></div>' +
          '<div style="margin-top:12px">' + (d.cards.map(function (c, i) { return '<div class="item"><div style="flex:1"><div class="t">' + SH.esc(c.q) + '</div><div class="meta">' + SH.esc(c.a) + '</div></div><button class="xbtn" data-delc="' + i + '" aria-label="Delete card" style="height:38px;width:38px">✕</button></div>'; }).join('') || '<p class="muted">No cards yet.</p>') + '</div>'
          : '<p class="muted">Create a deck to get started.</p>') + '</div></div>';
      }

      function drawStudy() {
        var d = deck(); if (!study) return;
        if (study.i >= study.queue.length) {
          panel.innerHTML = '<div class="card center"><h2>Round complete 🎉</h2><p>You knew <strong>' + study.known + '</strong> of ' + study.total + ' cards.</p><div class="btn-row" style="justify-content:center">' +
            (study.again.length ? '<button class="btn btn-primary" id="redo">Review ' + study.again.length + ' missed</button>' : '') + '<button class="btn" id="back">Back to deck</button></div></div>';
          return;
        }
        var c = study.queue[study.i];
        panel.innerHTML = '<div class="card"><div class="small muted" style="margin-bottom:8px">' + SH.esc(d.name) + ' · card ' + (study.i + 1) + ' of ' + study.queue.length + '</div>' +
          '<div class="bar" aria-hidden="true"><i style="width:' + (study.i / study.queue.length * 100) + '%"></i></div>' +
          '<div class="card fc" id="fc" role="button" tabindex="0" aria-label="Flip card"><div><small>' + (study.flip ? 'Answer' : 'Question – tap to flip') + '</small>' + SH.esc(study.flip ? c.a : c.q) + '</div></div>' +
          '<div class="btn-row" style="justify-content:center;margin-top:12px">' + (study.flip ? '<button class="btn" id="miss">Review again</button><button class="btn btn-primary" id="got">Got it</button>' : '<button class="btn btn-primary" id="show">Show answer</button>') + '</div>' +
          '<div class="center" style="margin-top:10px"><button class="btn btn-sm" id="back">Exit</button></div></div>';
      }

      function drawGen() {
        panel.innerHTML = '<div class="card"><div class="field"><label for="notes">Paste your own notes or reviewer text</label><textarea id="notes" style="min-height:180px" placeholder="Photosynthesis: the process by which plants convert light energy into chemical energy&#10;Chlorophyll: the green pigment that absorbs light&#10;Stomata - tiny pores that regulate gas exchange"></textarea></div>' +
          '<p class="small muted">Works best with lines like “Term: definition”, “Term – definition”, or sentences such as “X is defined as …”. Upload of files (PDF/Word) needs a document-parsing integration and is not included yet – paste text for now.</p>' +
          '<button class="btn btn-primary" id="run">Generate</button></div><div id="genout"></div>';
        if (gen) showGen();
      }
      function showGen() {
        var g = gen, out = SH.$('#genout', root);
        if (!g.cards.length) { out.innerHTML = '<div class="notice" style="margin-top:16px">No term–definition patterns were found. Try writing notes as “Term: definition” on separate lines.</div>'; return; }
        out.innerHTML = '<div class="card" style="margin-top:16px"><h2>Your reviewer</h2><h3>Key concepts</h3><p>' + g.concepts.map(SH.esc).join(' · ') + '</p>' +
          '<h3>Flashcards (' + g.cards.length + ')</h3>' + g.cards.map(function (c) { return '<div class="item"><div><div class="t">' + SH.esc(c.q) + '</div><div class="meta">' + SH.esc(c.a) + '</div></div></div>'; }).join('') +
          '<div class="btn-row" style="margin:12px 0"><input id="gname" placeholder="Deck name" style="max-width:260px" aria-label="Deck name"><button class="btn btn-primary" id="gsave">Save as deck</button></div>' +
          '<details><summary><strong>Short-answer practice</strong> (' + g.shortAnswer.length + ')</summary><ol>' + g.shortAnswer.map(function (s) { return '<li>' + SH.esc(s) + '</li>'; }).join('') + '</ol></details>' +
          '<details style="margin-top:8px"><summary><strong>Multiple-choice practice</strong> (' + g.mcq.length + ')</summary>' +
          (g.mcq.length ? g.mcq.map(function (m, i) { return '<div style="margin:12px 0"><strong>' + (i + 1) + '. ' + SH.esc(m.q) + '</strong><ol type="A">' + m.opts.map(function (o) { return '<li>' + SH.esc(o) + '</li>'; }).join('') + '</ol><span class="small muted">Answer: ' + 'ABCD'.charAt(m.ans) + '</span></div>'; }).join('') : '<p class="muted">Needs at least 4 terms to build multiple-choice questions.</p>') + '</details></div>';
        SH.$('#gsave', root).addEventListener('click', function () {
          var name = SH.$('#gname', root).value.trim() || 'Generated deck';
          var nd = { id: SH.uid(), name: name, cards: g.cards.map(function (c) { return { q: c.q, a: c.a }; }) };
          decks.push(nd); activeId = nd.id; save(); SH.history.add('deck', 'Created deck: ' + name, '/flashcards'); SH.toast('Deck saved'); tab = 'decks'; draw();
        });
      }

      function draw() { drawTabs(); if (study) drawStudy(); else if (tab === 'decks') drawDecks(); else drawGen(); }

      root.addEventListener('click', function (e) {
        var t, d = deck();
        if ((t = e.target.closest('[data-tab]'))) { tab = t.dataset.tab; study = null; draw(); }
        else if ((t = e.target.closest('[data-deck]'))) { activeId = t.dataset.deck; draw(); }
        else if ((t = e.target.closest('[data-delc]'))) { d.cards.splice(parseInt(t.dataset.delc, 10), 1); save(); draw(); }
        else if (e.target.closest('#deldeck')) { if (confirm('Delete this deck?')) { decks = decks.filter(function (x) { return x.id !== activeId; }); activeId = decks.length ? decks[0].id : null; save(); draw(); } }
        else if (e.target.closest('#study')) { var q = d.cards.slice().sort(function () { return Math.random() - 0.5; }); study = { queue: q, i: 0, flip: false, known: 0, total: q.length, again: [] }; draw(); }
        else if (e.target.closest('#fc') || e.target.closest('#show')) { study.flip = !study.flip; draw(); }
        else if (e.target.closest('#got')) { study.known++; study.i++; study.flip = false; draw(); }
        else if (e.target.closest('#miss')) { study.again.push(study.queue[study.i]); study.i++; study.flip = false; draw(); }
        else if (e.target.closest('#redo')) { study = { queue: study.again.slice(), i: 0, flip: false, known: 0, total: study.again.length, again: [] }; draw(); }
        else if (e.target.closest('#back')) { study = null; draw(); }
        else if (e.target.closest('#run')) { gen = SH.lib.generateFromNotes(SH.$('#notes', root).value); showGen(); }
      });
      root.addEventListener('submit', function (e) {
        e.preventDefault();
        if (e.target.id === 'nd') {
          var n = SH.$('#dn', root).value.trim(); if (!n) return;
          var nd = { id: SH.uid(), name: n, cards: [] }; decks.push(nd); activeId = nd.id; save(); draw();
        } else if (e.target.id === 'nc') {
          deck().cards.push({ q: SH.$('#cq', root).value.trim(), a: SH.$('#ca', root).value.trim() }); save(); draw();
          var cq = SH.$('#cq', root); if (cq) cq.focus();
        }
      });
      root.addEventListener('keydown', function (e) { if (e.target.id === 'fc' && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); study.flip = !study.flip; draw(); } });
      draw();
    }
  });
})();
