/* Homepage + section hubs (Study Tools / Research / Career) */
(function () {
  'use strict';
  var SH = window.SH;

  var EXAMPLES = ['Calculate my grade', 'Make an APA citation', 'Create a study plan', 'Make flashcards', 'Build my CV'];

  function searchBlock() {
    return '<div class="search" role="search"><span class="mag" aria-hidden="true">🔍</span>' +
      '<input id="q" type="search" placeholder="What do you need help with?" aria-label="What do you need help with?" autocomplete="off" aria-controls="res">' +
      '<div class="results" id="res" hidden></div></div>' +
      '<div class="chips" aria-label="Try searching for">' + EXAMPLES.map(function (e) { return '<button class="chip" data-q="' + SH.esc(e) + '">' + SH.esc(e) + '</button>'; }).join('') + '</div>';
  }

  function bindSearch(root) {
    var q = SH.$('#q', root), res = SH.$('#res', root);
    var alias = { 'calculate my grade': 'grade calculator', 'make an apa citation': 'apa citation', 'create a study plan': 'study planner', 'make flashcards': 'flashcards', 'build my cv': 'cv builder' };
    function run() {
      var raw = q.value.trim(), term = alias[raw.toLowerCase()] || raw;
      if (!raw) { res.hidden = true; return; }
      var hits = SH.search(term);
      res.hidden = false;
      res.innerHTML = hits.length
        ? hits.map(function (t) {
            return '<a href="#' + t.route + '"><span aria-hidden="true">' + t.icon + '</span><span><strong>' + SH.esc(t.name) + '</strong>' +
              (t.status === 'soon' ? ' <span class="tag soon">Coming soon</span>' : '') + '<br><span class="small muted">' + SH.esc(t.desc) + '</span></span></a>';
          }).join('')
        : '<div style="padding:14px" class="muted">No tools match “' + SH.esc(raw) + '” yet. Try “grade”, “citation” or “cv”.</div>';
    }
    q.addEventListener('input', run);
    q.addEventListener('keydown', function (e) { if (e.key === 'Enter') { var f = SH.$('#res a', root); if (f) f.click(); } });
    SH.$$('.chip', root).forEach(function (c) { c.addEventListener('click', function () { q.value = c.getAttribute('data-q'); run(); q.focus(); }); });
    function outside(e) { if (!e.target.closest('.search') && !e.target.closest('.chip')) res.hidden = true; }
    document.addEventListener('click', outside); SH.onLeave(function () { document.removeEventListener('click', outside); });
  }

  SH.addRoute('/', {
    title: 'StudentHub PH – Free Student Tools for Filipino Students',
    desc: 'Free student tools for Filipino students: grade calculator, GPA calculator, APA 7 citation generator, study planner, flashcards and CV builder – all in one place.',
    render: function (root) {
      var live = SH.tools.filter(function (t) { return t.status === 'live'; });
      var soon = SH.tools.filter(function (t) { return t.status === 'soon'; });
      var u = SH.auth.user();
      root.innerHTML =
        '<section class="hero"><div class="wrap"><span class="tag">Built for Filipino students</span>' +
        '<h1 style="margin-top:14px">Everything Students Need. <em>In One Place.</em></h1>' +
        '<p class="lead">Study smarter, organize your academic life, build your career, and get more things done with free student tools.</p>' +
        '<div class="btn-row" style="justify-content:center"><a class="btn btn-primary" href="#tools">Explore Free Tools</a>' +
        (u ? '<a class="btn" href="#/dashboard">Go to dashboard</a>' : '<a class="btn" href="#/signup">Create Free Account</a>') + '</div>' +
        searchBlock() + '</div></section>' +
        '<section class="section" id="tools"><div class="wrap"><h2>Free tools, ready to use</h2>' +
        '<p class="muted">No account needed to try them. Create a free account to keep your work across sessions on this site.</p>' +
        '<div class="grid g3">' + live.map(SH.toolCard).join('') + '</div></div></section>' +
        '<section class="section"><div class="wrap"><div class="grid g3">' +
        '<div class="card"><h3>📱 Mobile-first</h3><p class="muted">Big touch targets and light pages, because most students use their phones.</p></div>' +
        '<div class="card"><h3>🔒 Respectful of your data</h3><p class="muted">We do not sell student information. See our <a href="#/privacy">Privacy Policy</a>.</p></div>' +
        '<div class="card"><h3>🎯 Learning first</h3><p class="muted">Tools are study aids. Verify facts and follow your school’s academic-integrity rules.</p></div></div></div></section>' +
        '<section class="section"><div class="wrap"><h2>Coming next</h2><p class="muted">We are building the core tools first and expanding based on what students actually use.</p>' +
        '<div class="grid g3">' + soon.slice(0, 6).map(SH.toolCard).join('') + '</div></div></section>';
      bindSearch(root);
      SH.$('a[href="#tools"]', root).addEventListener('click', function (e) { e.preventDefault(); SH.$('#tools').scrollIntoView({ behavior: 'smooth' }); });
    }
  });

  function hub(path, section, title, h1, desc, meta) {
    SH.addRoute(path, {
      title: title, desc: meta,
      render: function (root) {
        root.innerHTML = '<div class="wrap">' + SH.pageHead(h1, desc, '<a href="#/">Home</a>') + '<div class="grid g3" style="margin-bottom:30px">' +
          SH.toolsIn(section).map(SH.toolCard).join('') + '</div></div>';
      }
    });
  }
  hub('/study-tools', 'study', 'Student Tools – Grade, GPA, Planner & Flashcards | StudentHub PH', 'Study Tools',
    'Calculate grades and GPA, plan your study sessions and review with flashcards.',
    'Free student tools for the Philippines: grade calculator, GPA calculator, study planner and flashcards.');
  hub('/research', 'research', 'Research & Thesis Tools – APA 7 Citations | StudentHub PH', 'Research & Thesis Tools',
    'Cite sources in APA 7 and organize your thesis work.',
    'APA 7 citation generator and thesis tools for Filipino students.');
  hub('/career', 'career', 'Career Tools – CV Builder, Internships & Scholarships | StudentHub PH', 'Career Hub',
    'Build your CV and, soon, find internships and scholarships.',
    'CV builder for Filipino students, plus upcoming internship and scholarship finders.');
})();
