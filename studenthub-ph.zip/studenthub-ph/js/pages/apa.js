/* APA 7 Citation Generator – pure formatter (SH.lib.apa) + UI */
(function () {
  'use strict';
  var SH = window.SH;
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var e = SH.esc;

  function endDot(s) { s = String(s || '').trim(); return /[.?!]$/.test(s) ? s : s + '.'; }

  /* "Last, First Middle" or "First Middle Last" → { last, init } */
  function parseAuthor(line) {
    line = line.trim(); if (!line) return null;
    var last, first;
    if (line.indexOf(',') > -1) { var p = line.split(','); last = p[0].trim(); first = p.slice(1).join(' ').trim(); }
    else { var w = line.split(/\s+/); last = w.pop(); first = w.join(' '); }
    var init = first.split(/\s+/).filter(Boolean).map(function (n) {
      return n.split('-').map(function (x) { return x.charAt(0).toUpperCase() + '.'; }).join('-');
    }).join(' ');
    return { last: last, init: init };
  }

  function authors(text, isOrg) {
    var lines = String(text || '').split(/\n/).map(function (x) { return x.trim(); }).filter(Boolean);
    if (isOrg) return lines.slice(0, 1).map(function (n) { return { org: n }; });
    return lines.map(parseAuthor).filter(Boolean);
  }
  function nameRef(a) { return a.org ? a.org : a.last + (a.init ? ', ' + a.init : ''); }
  function refAuthors(list) {
    if (!list.length) return '';
    var n = list.map(nameRef);
    if (n.length === 1) return n[0];
    if (n.length === 2) return n[0] + ', & ' + n[1];
    if (n.length <= 20) return n.slice(0, -1).join(', ') + ', & ' + n[n.length - 1];
    return n.slice(0, 19).join(', ') + ', . . . ' + n[n.length - 1];
  }
  function inAuthors(list) {
    var n = list.map(function (a) { return a.org || a.last; });
    if (n.length === 1) return n[0];
    if (n.length === 2) return n[0] + ' & ' + n[1];
    return n[0] + ' et al.';
  }
  function dateStr(d, yearOnly) {
    d = String(d || '').trim();
    var m = d.match(/^(\d{4})(?:-(\d{1,2}))?(?:-(\d{1,2}))?$/);
    if (!m) return d ? d : 'n.d.';
    if (yearOnly || !m[2]) return m[1];
    var mo = MONTHS[parseInt(m[2], 10) - 1]; if (!mo) return m[1];
    return m[1] + ', ' + mo + (m[3] ? ' ' + parseInt(m[3], 10) : '');
  }
  function year(d) { var m = String(d || '').match(/^(\d{4})/); return m ? m[1] : 'n.d.'; }
  function link(f) {
    var doi = String(f.doi || '').trim();
    if (doi) { doi = doi.replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').replace(/^doi:\s*/i, ''); return 'https://doi.org/' + doi; }
    return String(f.url || '').trim();
  }
  var TYPES = {
    book: { label: 'Book', italic: true }, journal: { label: 'Journal article', italic: false },
    website: { label: 'Web page / website', italic: false }, report: { label: 'Report', italic: true }, video: { label: 'Video', italic: true }
  };

  /* returns { html, text, intext, intextText, sortKey } */
  SH.lib.apa = function (type, f) {
    var au = authors(f.authors, f.org), title = String(f.title || '').trim() || '[Title]';
    var hasAu = au.length > 0, auStr = refAuthors(au);
    var lk = link(f), yr = year(f.date);
    var date = (type === 'website' || type === 'video') ? dateStr(f.date) : dateStr(f.date, true);
    var T = e(title), html;
    var head = function (italicTitle, titleExtra) {
      var tt = italicTitle ? '<i>' + T + '</i>' : T;
      return hasAu ? e(endDot(auStr)) + ' (' + e(date) + '). ' + tt + (titleExtra || '') + '. '
                   : tt + (titleExtra || '') + '. (' + e(date) + '). ';
    };
    var tail = lk ? e(lk) : '';
    if (type === 'journal') {
      var vol = f.volume ? '<i>' + e(f.journal || '') + ', ' + e(f.volume) + '</i>' : '<i>' + e(f.journal || '') + '</i>';
      html = head(false) + vol + (f.issue ? '(' + e(f.issue) + ')' : '') + (f.pages ? ', ' + e(f.pages) : '') + '. ' + tail;
    } else if (type === 'book') {
      html = head(true, f.edition ? ' (' + e(f.edition) + ' ed.)' : '') + (f.publisher ? e(endDot(f.publisher)) + ' ' : '') + tail;
    } else if (type === 'report') {
      html = head(true, f.number ? ' (' + e(f.number) + ')' : '') + (f.publisher && f.publisher !== auStr ? e(endDot(f.publisher)) + ' ' : '') + tail;
    } else if (type === 'video') {
      html = head(true, ' [Video]') + (f.publisher ? e(endDot(f.publisher)) + ' ' : '') + tail;
    } else { // website
      html = head(true) + (f.publisher && f.publisher !== auStr ? e(endDot(f.publisher)) + ' ' : '') + tail;
    }
    html = html.trim();
    var short = title.length > 50 ? title.slice(0, 47).replace(/\s+\S*$/, '') + '…' : title;
    var quote = !TYPES[type].italic || type === 'website';
    var lead = hasAu ? inAuthors(au) : (quote ? '“' + e(short) + '”' : '<i>' + e(short) + '</i>');
    var leadText = hasAu ? inAuthors(au) : (quote ? '“' + short + '”' : short);
    var tmp = document.createElement ? document.createElement('div') : null;
    var text = tmp ? (function () { tmp.innerHTML = html; return tmp.textContent; })() : html.replace(/<[^>]+>/g, '');
    return {
      html: html, text: text,
      intext: '(' + (hasAu ? e(lead) : lead) + ', ' + e(yr) + ')',
      intextText: '(' + leadText + ', ' + yr + ')',
      narrative: hasAu ? (inAuthors(au) + ' (' + yr + ')') : '',
      sortKey: (hasAu ? nameRef(au[0]) : title).toLowerCase()
    };
  };

  var FIELDS = {
    book: [['edition', 'Edition (e.g. 2nd)'], ['publisher', 'Publisher'], ['url', 'URL (optional)'], ['doi', 'DOI (optional)']],
    journal: [['journal', 'Journal name'], ['volume', 'Volume'], ['issue', 'Issue'], ['pages', 'Pages (e.g. 12–29)'], ['doi', 'DOI'], ['url', 'URL (if no DOI)']],
    website: [['publisher', 'Website name'], ['url', 'URL']],
    report: [['number', 'Report number (optional, e.g. Report No. 12)'], ['publisher', 'Publisher / agency'], ['url', 'URL'], ['doi', 'DOI (optional)']],
    video: [['publisher', 'Platform (e.g. YouTube)'], ['url', 'URL']]
  };

  SH.addRoute('/apa-citation-generator', {
    title: 'APA 7 Citation Generator – Free Reference & In-Text Citations | StudentHub PH',
    desc: 'Free APA 7th edition citation generator for books, journal articles, websites, reports and videos. Get the reference entry and in-text citation, with DOI and multiple-author support.',
    render: function (root) {
      var type = 'journal', current = null;
      root.innerHTML = '<div class="wrap">' + SH.pageHead('APA 7 Citation Generator',
        'Fill in the details to get an APA 7th edition reference entry and in-text citation.', '<a href="#/research">Research</a> › APA 7 Citation Generator') +
        '<div class="notice info">This tool gives formatting assistance. Always check your result against the official <a href="https://apastyle.apa.org/" target="_blank" rel="noopener">APA Style guidance</a> and your instructor’s requirements. Titles must already be in the correct case (sentence case for most titles).</div>' +
        '<div class="split"><div class="card"><div class="tabs" role="tablist" id="types"></div><form id="f" autocomplete="off"><div id="fields"></div>' +
        '<div class="btn-row"><button class="btn btn-primary" type="submit">Generate citation</button></div></form></div>' +
        '<div><div class="card" id="result" aria-live="polite"><h2>Result</h2><p class="muted">Your citation will appear here.</p></div>' +
        '<div class="card" style="margin-top:16px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><h3 style="margin:0">My reference list</h3><button class="btn btn-sm" id="copyall">Copy all</button></div><div id="list" style="margin-top:12px"></div></div></div></div></div>';

      var tabs = SH.$('#types', root), fieldsEl = SH.$('#fields', root), result = SH.$('#result', root), list = SH.$('#list', root);
      function drawTabs() {
        tabs.innerHTML = Object.keys(TYPES).map(function (k) { return '<button type="button" class="tab" role="tab" aria-selected="' + (k === type) + '" data-t="' + k + '">' + TYPES[k].label + '</button>'; }).join('');
      }
      function drawFields() {
        var f = FIELDS[type];
        fieldsEl.innerHTML =
          '<div class="field"><label for="org" style="display:flex;gap:8px;align-items:center;font-weight:500"><input type="checkbox" id="org" style="width:auto;min-height:0"> Author is an organization / group</label></div>' +
          '<div class="field"><label for="authors">Authors <span class="muted">(one per line: Last, First Middle)</span></label><textarea id="authors" placeholder="Santos, Maria Clara&#10;Reyes, Jose P."></textarea></div>' +
          '<div class="row c2"><div class="field"><label for="date">Date <span class="muted">(YYYY, YYYY-MM or YYYY-MM-DD)</span></label><input id="date" placeholder="2024"></div>' +
          '<div class="field"><label for="title">Title</label><input id="title" required></div></div>' +
          '<div class="row c2">' + f.map(function (x) { return '<div class="field"><label for="' + x[0] + '">' + x[1] + '</label><input id="' + x[0] + '"></div>'; }).join('') + '</div>';
      }
      function read() {
        var o = {}; SH.$$('input,textarea', fieldsEl).forEach(function (i) { o[i.id] = i.type === 'checkbox' ? i.checked : i.value; }); return o;
      }
      function drawList() {
        var refs = SH.db.get('refs', []).sort(function (a, b) { return a.sortKey < b.sortKey ? -1 : 1; });
        list.innerHTML = refs.length ? refs.map(function (r) {
          return '<div class="ref">' + r.html + ' <button class="btn btn-sm btn-danger" data-rm="' + r.id + '" aria-label="Remove reference" style="text-indent:0">Remove</button></div>';
        }).join('') : '<p class="muted small">Saved references appear here, sorted alphabetically like an APA reference list.</p>';
      }
      tabs.addEventListener('click', function (ev) { var b = ev.target.closest('[data-t]'); if (!b) return; type = b.dataset.t; current = null; drawTabs(); drawFields(); });
      SH.$('#f', root).addEventListener('submit', function (ev) {
        ev.preventDefault();
        var d = read();
        if (!d.title.trim()) { SH.toast('Please enter a title'); return; }
        current = SH.lib.apa(type, d);
        var warn = [];
        if (!current.html.match(/\(.+\)/)) warn = [];
        if (!d.authors.trim()) warn.push('No author entered – the title moves to the author position, as APA requires.');
        if (type === 'journal' && !d.journal) warn.push('Journal name is missing.');
        if (!d.date.trim()) warn.push('No date entered – “n.d.” was used.');
        result.innerHTML = '<h2>Result</h2><h3>Reference entry</h3><div class="out ref" id="r1">' + current.html + '</div>' +
          '<h3 style="margin-top:14px">In-text citation</h3><div class="out" id="r2">Parenthetical: ' + current.intext + (current.narrative ? '<br>Narrative: ' + e(current.narrative) : '') + '</div>' +
          (warn.length ? '<div class="notice" style="margin-top:12px">' + warn.map(e).join('<br>') + '</div>' : '') +
          '<div class="btn-row" style="margin-top:12px"><button class="btn btn-sm" id="c1">Copy reference</button><button class="btn btn-sm" id="c2">Copy in-text</button><button class="btn btn-sm btn-primary" id="sv">Add to my list</button></div>';
        SH.$('#c1', result).addEventListener('click', function () { SH.copyRich(current.html, current.text); });
        SH.$('#c2', result).addEventListener('click', function () { SH.copyRich(current.intext, current.intextText); });
        SH.$('#sv', result).addEventListener('click', function () {
          var refs = SH.db.get('refs', []); refs.push({ id: SH.uid(), html: current.html, text: current.text, sortKey: current.sortKey });
          SH.db.set('refs', refs); SH.history.add('citation', 'Saved APA reference: ' + (d.title.length > 40 ? d.title.slice(0, 40) + '…' : d.title), '/apa-citation-generator'); drawList(); SH.toast('Added to your list');
        });
      });
      list.addEventListener('click', function (ev) {
        var b = ev.target.closest('[data-rm]'); if (!b) return;
        SH.db.set('refs', SH.db.get('refs', []).filter(function (r) { return r.id !== b.dataset.rm; })); drawList();
      });
      SH.$('#copyall', root).addEventListener('click', function () {
        var refs = SH.db.get('refs', []).sort(function (a, b) { return a.sortKey < b.sortKey ? -1 : 1; });
        if (!refs.length) { SH.toast('Your list is empty'); return; }
        SH.copyRich(refs.map(function (r) { return '<p style="padding-left:.5in;text-indent:-.5in">' + r.html + '</p>'; }).join(''), refs.map(function (r) { return r.text; }).join('\n\n'));
      });
      drawTabs(); drawFields(); drawList();
    }
  });
})();
