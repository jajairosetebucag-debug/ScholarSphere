/* CV Builder – structured form, live preview, 3 templates, PDF via the browser's Save-as-PDF print dialog.
   INTEGRATION (later): server-side PDF rendering if you want one-click download without the print dialog. */
(function () {
  'use strict';
  var SH = window.SH, e = SH.esc;

  var LISTS = {
    education: { title: 'Education', fields: [['school', 'School'], ['degree', 'Degree / program'], ['years', 'Years'], ['details', 'Details (honors, thesis…)']] },
    experience: { title: 'Experience', fields: [['role', 'Role'], ['org', 'Organization'], ['years', 'Years'], ['details', 'What you did (one point per line)']] },
    projects: { title: 'Projects', fields: [['name', 'Project'], ['details', 'Description']] },
    certs: { title: 'Certifications', fields: [['name', 'Certification'], ['issuer', 'Issuer'], ['year', 'Year']] }
  };

  function blank() {
    return { tpl: 'classic', p: { name: '', title: '', email: '', phone: '', address: '', links: '', summary: '' },
      education: [], experience: [], projects: [], certs: [], skills: '', achievements: '', references: 'Available upon request.' };
  }

  function lines(t) { return String(t || '').split(/\n/).map(function (x) { return x.trim(); }).filter(Boolean); }
  function bullets(t) { var l = lines(t); return l.length ? '<ul style="margin:2px 0 0 18px;padding:0">' + l.map(function (x) { return '<li>' + e(x) + '</li>'; }).join('') + '</ul>' : ''; }

  SH.lib.cvHtml = function (d) {
    var p = d.p, contact = [p.email, p.phone, p.address, p.links].filter(Boolean).map(e).join(' · ');
    var head = d.tpl === 'modern'
      ? '<div class="top"><h1>' + e(p.name || 'Your Name') + '</h1><div class="sub">' + e(p.title) + '</div><div class="sub">' + contact + '</div></div>'
      : '<h1>' + e(p.name || 'Your Name') + '</h1><div class="sub">' + e(p.title) + '</div><div class="sub">' + contact + '</div>';
    function sec(title, body) { return body ? '<h2>' + title + '</h2>' + body : ''; }
    var h = head;
    h += sec('Profile', p.summary ? '<div class="pre">' + e(p.summary) + '</div>' : '');
    h += sec('Education', d.education.map(function (x) { return '<div class="ent"><b>' + e(x.degree) + '</b>' + (x.school ? ', ' + e(x.school) : '') + (x.years ? ' <span class="sub">(' + e(x.years) + ')</span>' : '') + (x.details ? '<div>' + e(x.details) + '</div>' : '') + '</div>'; }).join(''));
    h += sec('Experience', d.experience.map(function (x) { return '<div class="ent"><b>' + e(x.role) + '</b>' + (x.org ? ', ' + e(x.org) : '') + (x.years ? ' <span class="sub">(' + e(x.years) + ')</span>' : '') + bullets(x.details) + '</div>'; }).join(''));
    h += sec('Skills', lines(d.skills.replace(/,/g, '\n')).length ? '<div>' + lines(d.skills.replace(/,/g, '\n')).map(e).join(' · ') + '</div>' : '');
    h += sec('Projects', d.projects.map(function (x) { return '<div class="ent"><b>' + e(x.name) + '</b>' + (x.details ? '<div>' + e(x.details) + '</div>' : '') + '</div>'; }).join(''));
    h += sec('Certifications', d.certs.map(function (x) { return '<div class="ent"><b>' + e(x.name) + '</b>' + (x.issuer ? ', ' + e(x.issuer) : '') + (x.year ? ' (' + e(x.year) + ')' : '') + '</div>'; }).join(''));
    h += sec('Achievements', bullets(d.achievements));
    h += sec('References', d.references ? '<div class="pre">' + e(d.references) + '</div>' : '');
    return h;
  };

  SH.addRoute('/cv-builder', {
    title: 'CV Builder Philippines – Free Resume Maker with PDF Export | StudentHub PH',
    desc: 'Free CV builder for Filipino students and fresh graduates. Fill in your education, experience and skills, choose a clean template and export to PDF.',
    render: function (root) {
      var d = SH.db.get('cv', null) || blank();
      root.innerHTML = '<div class="wrap">' + SH.pageHead('CV Builder', 'Fill in your details, pick a template and export a clean PDF. Your CV is saved in this browser as you type.', '<a href="#/career">Career</a> › CV Builder') +
        '<div class="split"><div id="form"></div><div><div class="card"><div class="field"><label for="tpl">Template</label><select id="tpl"><option value="classic">Classic</option><option value="modern">Modern</option><option value="compact">Compact</option></select></div>' +
        '<div class="btn-row"><button class="btn btn-primary" id="pdf">Download PDF</button><button class="btn" id="clear">Start over</button></div>' +
        '<p class="small muted" style="margin-top:8px">“Download PDF” opens your browser’s print dialog – choose <em>Save as PDF</em>. Tip: turn off “Headers and footers”.</p></div>' +
        '<h3 style="margin-top:16px">Preview</h3><div class="cv-paper" id="prev"></div></div></div></div>';

      var form = SH.$('#form', root), prev = SH.$('#prev', root), tpl = SH.$('#tpl', root);
      function save() { SH.db.set('cv', d); }
      function preview() { prev.className = 'cv-paper cv-' + d.tpl; prev.innerHTML = SH.lib.cvHtml(d); save(); }
      function input(label, key, val, attrs) { return '<div class="field"><label>' + label + '</label>' + (attrs === 'ta' ? '<textarea data-k="' + key + '">' + e(val) + '</textarea>' : '<input data-k="' + key + '" value="' + e(val) + '">') + '</div>'; }

      function drawForm() {
        var h = '<details class="card" open><summary>Personal information</summary><div class="row c2" style="margin-top:10px">' +
          input('Full name', 'p.name', d.p.name) + input('Headline (e.g. BS Biology student)', 'p.title', d.p.title) + input('Email', 'p.email', d.p.email) + input('Phone', 'p.phone', d.p.phone) +
          input('Address (city, province)', 'p.address', d.p.address) + input('Links (LinkedIn, portfolio)', 'p.links', d.p.links) + '</div>' + input('Profile summary', 'p.summary', d.p.summary, 'ta') + '</details>';
        Object.keys(LISTS).forEach(function (k) {
          var L = LISTS[k];
          h += '<details class="card" style="margin-top:12px"' + (d[k].length ? ' open' : '') + '><summary>' + L.title + ' (' + d[k].length + ')</summary>' +
            d[k].map(function (it, i) {
              return '<div class="sub-block">' + L.fields.map(function (f) { return input(f[1], k + '.' + i + '.' + f[0], it[f[0]] || '', /details/.test(f[0]) ? 'ta' : ''); }).join('') + '<button class="btn btn-sm btn-danger" data-rm="' + k + ':' + i + '">Remove</button></div>';
            }).join('') + '<button class="btn btn-sm" data-add="' + k + '">+ Add</button></details>';
        });
        h += '<details class="card" style="margin-top:12px"><summary>Skills, achievements, references</summary>' + input('Skills (comma-separated)', 'skills', d.skills, 'ta') + input('Achievements (one per line)', 'achievements', d.achievements, 'ta') + input('References', 'references', d.references, 'ta') + '</details>';
        form.innerHTML = h; tpl.value = d.tpl;
      }
      function setKey(path, v) {
        var k = path.split('.');
        if (k.length === 1) d[k[0]] = v; else if (k[0] === 'p') d.p[k[1]] = v; else d[k[0]][parseInt(k[1], 10)][k[2]] = v;
      }
      form.addEventListener('input', function (ev) { var k = ev.target.dataset.k; if (k) { setKey(k, ev.target.value); preview(); } });
      form.addEventListener('click', function (ev) {
        var a = ev.target.closest('[data-add]'), r = ev.target.closest('[data-rm]');
        if (a) { d[a.dataset.add].push({}); drawForm(); preview(); }
        if (r) { var p = r.dataset.rm.split(':'); d[p[0]].splice(parseInt(p[1], 10), 1); drawForm(); preview(); }
      });
      tpl.addEventListener('change', function () { d.tpl = tpl.value; preview(); });
      SH.$('#clear', root).addEventListener('click', function () { if (confirm('Clear your CV and start over?')) { d = blank(); drawForm(); preview(); } });
      SH.$('#pdf', root).addEventListener('click', function () {
        document.body.classList.add('print-cv'); SH.history.add('cv', 'Exported CV' + (d.p.name ? ': ' + d.p.name : ''), '/cv-builder');
        window.print();
        setTimeout(function () { document.body.classList.remove('print-cv'); }, 500);
      });
      drawForm(); preview();
    }
  });
})();
