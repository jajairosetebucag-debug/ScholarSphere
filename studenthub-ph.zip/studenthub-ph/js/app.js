/* App shell: hash router, header/footer, per-route SEO metadata. */
(function () {
  'use strict';
  var SH = window.SH;
  var LOGO = '<svg viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" rx="11" fill="#4f46e5"/><path d="M20 9l13 6.5L20 22 7 15.5z" fill="#fff"/><path d="M12.5 19.5v6c0 2 3.4 4 7.500 4s7.500-2 7.500-4v-6L20 25z" fill="#fff" opacity=".82"/><circle cx="33" cy="17" r="2.2" fill="#a5b4fc"/><path d="M33 19v7" stroke="#a5b4fc" stroke-width="1.8" stroke-linecap="round"/></svg>';
  SH.LOGO = LOGO;


  var NAV = [
    ['/', 'Home'], ['/study-tools', 'Study Tools'], ['/research', 'Research'], ['/career', 'Career'],
    ['/templates', 'Templates'], ['/scholarships', 'Scholarships'], ['/internships', 'Internships'],
    ['/resources', 'Resources'], ['/pricing', 'Pricing']
  ];

  function parse() {
    var h = location.hash.replace(/^#/, '') || '/';
    var q = h.indexOf('?'), path = q > -1 ? h.slice(0, q) : h, params = {};
    if (q > -1) h.slice(q + 1).split('&').forEach(function (p) { var kv = p.split('='); params[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || ''); });
    return { path: path || '/', params: params };
  }

  function activeFor(path, href) {
    if (href === '/') return path === '/';
    if (path === href) return true;
    var t = SH.tools.filter(function (x) { return x.route === path; })[0];
    if (!t) return false;
    var map = { '/study-tools': 'study', '/research': 'research', '/career': 'career' };
    return map[href] === t.section && t.section !== 'resources';
  }

  SH.renderHeader = function () {
    var cur = parse().path, u = SH.auth.user();
    var links = NAV.map(function (n) {
      return '<a href="#' + n[0] + '"' + (activeFor(cur, n[0]) ? ' class="active" aria-current="page"' : '') + '>' + n[1] + '</a>';
    }).join('');
    var acct = u
      ? '<a href="#/dashboard"' + (cur === '/dashboard' ? ' class="active"' : '') + '>Dashboard</a><a href="#/profile">Profile</a><a href="#" data-logout>Log out</a>'
      : '<a href="#/login">Log in</a><a class="btn btn-primary btn-sm cta" href="#/signup" style="color:#fff">Sign up free</a>';
    SH.$('#header').innerHTML =
      '<div class="wrap hwrap"><div class="hbar"><a class="logo" href="#/" aria-label="StudentHub PH home">' + LOGO + '<span>StudentHub <b>PH</b></span></a>' +
      '<button class="burger" aria-label="Menu" aria-expanded="false" aria-controls="nav">☰</button></div>' +
      '<nav class="nav" id="nav" aria-label="Main">' + links + acct + '</nav></div>';
    var b = SH.$('.burger'), nav = SH.$('#nav');
    b.addEventListener('click', function () { var o = nav.classList.toggle('open'); b.setAttribute('aria-expanded', o); b.textContent = o ? '✕' : '☰'; });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('[data-logout]')) { e.preventDefault(); SH.auth.logOut(); SH.toast('Logged out'); SH.go('/'); }
      else if (e.target.closest('a')) { nav.classList.remove('open'); b.textContent = '☰'; b.setAttribute('aria-expanded', false); }
    });
  };

  SH.renderFooter = function () {
    SH.$('#footer').innerHTML =
      '<div class="wrap"><div class="cols"><div><a class="logo" href="#/" style="padding:0">' + LOGO + '<span>StudentHub <b>PH</b></span></a>' +
      '<p class="muted" style="margin-top:10px;max-width:340px">Everything Students Need. In One Place. Free tools for Filipino students.</p></div>' +
      '<div><strong>Tools</strong><a href="#/grade-calculator">Grade Calculator</a><a href="#/gpa-calculator">GPA Calculator</a><a href="#/apa-citation-generator">APA 7 Generator</a><a href="#/cv-builder">CV Builder</a></div>' +
      '<div><strong>Company</strong><a href="#/pricing">Pricing</a><a href="#/contact">Contact</a><a href="#/report-issue">Report an issue</a></div>' +
      '<div><strong>Legal</strong><a href="#/privacy">Privacy Policy</a><a href="#/terms">Terms of Service</a><a href="#/cookies">Cookie Policy</a><a href="#/disclaimer">Disclaimer</a></div></div>' +
      '<p class="small muted" style="margin-top:20px">© ' + new Date().getFullYear() + ' StudentHub PH. Study aids support your learning – always follow your school’s academic-integrity policy.</p></div>';
  };

  function setMeta(title, desc) {
    document.title = title || 'StudentHub PH – Everything Students Need. In One Place.';
    var m = document.querySelector('meta[name=description]');
    if (m && desc) m.setAttribute('content', desc);
  }

  SH.render = function () {
    var r = parse(), def = SH.routes[r.path];
    (SH._leave || []).forEach(function (f) { try { f(); } catch (e) {} }); SH._leave = [];
    /* fresh <main> per navigation so listeners from the previous page are discarded */
    var old = SH.$('#app'), root = old.cloneNode(false); old.parentNode.replaceChild(root, old);
    if (!def) def = SH.routes['/404'];
    if (def.auth && !SH.auth.user()) { SH.go('/login?next=' + encodeURIComponent(r.path)); return; }
    root.innerHTML = '';
    setMeta(def.title, def.desc);
    try { def.render(root, r.params); }
    catch (e) { console.error(e); root.innerHTML = '<div class="wrap section"><div class="card"><h2>Something went wrong</h2><p>Please refresh the page. If it keeps happening, use “Report an issue”.</p></div></div>'; }
    SH.renderHeader();
    window.scrollTo(0, 0);
    SH.track('page_view', { path: r.path });
  };

  SH.addRoute('/404', {
    title: 'Page not found – StudentHub PH', desc: 'This page could not be found.',
    render: function (root) {
      root.innerHTML = '<div class="wrap section center"><h1>Page not found</h1><p class="muted">The page you are looking for does not exist.</p><a class="btn btn-primary" href="#/">Back to home</a></div>';
    }
  });

  SH.auth.onChange(function () { SH.renderHeader(); });
  window.addEventListener('hashchange', SH.render);
  SH.renderFooter();
  SH.render();
})();
