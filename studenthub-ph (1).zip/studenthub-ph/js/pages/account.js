/* Account pages: sign up, log in, reset password, profile, dashboard, pricing */
(function () {
  'use strict';
  var SH = window.SH, e = SH.esc;

  var DEV = '<div class="notice" data-dev><strong>Development build.</strong> Accounts are stored only in this browser and are not secure or shared across devices. Production needs a real authentication provider (see README).</div>';

  function authPage(path, title, desc, body, bind) {
    SH.addRoute(path, {
      title: title, desc: desc,
      render: function (root, params) {
        if (SH.auth.user() && path !== '/reset') { SH.go('/dashboard'); return; }
        root.innerHTML = '<div class="wrap section" style="max-width:460px">' + body + '</div>';
        if (SH.backend !== 'local') SH.$$('.notice[data-local-only],.notice[data-dev]', root).forEach(function (n) { n.remove(); });
        bind(root, params);
      }
    });
  }
  function errBox(root, msg) { var b = SH.$('#err', root); b.hidden = !msg; b.textContent = msg || ''; }

  authPage('/signup', 'Create Free Account | StudentHub PH', 'Create a free StudentHub PH account to keep your study plans, flashcards, citations and CV.',
    '<div class="card"><h1 style="font-size:1.6rem">Create your free account</h1>' + DEV +
    '<form id="f"><div class="field"><label for="n">Name</label><input id="n" autocomplete="name" required></div><div class="field"><label for="em">Email</label><input id="em" type="email" autocomplete="email" required></div>' +
    '<div class="field"><label for="pw">Password <span class="muted">(8+ characters)</span></label><input id="pw" type="password" autocomplete="new-password" required></div>' +
    '<div class="notice" id="err" role="alert" hidden style="background:#fef2f2;border-color:#fecaca;color:#991b1b"></div>' +
    '<button class="btn btn-primary" style="width:100%" type="submit">Sign up</button></form><p class="small muted" style="margin-top:12px">By signing up you agree to the <a href="#/terms">Terms</a> and <a href="#/privacy">Privacy Policy</a>. Work you did as a guest on this device is carried over.</p>' +
    '<p class="small">Already have an account? <a href="#/login">Log in</a></p></div>',
    function (root) {
      SH.$('#f', root).addEventListener('submit', function (ev) {
        ev.preventDefault(); errBox(root, '');
        SH.auth.signUp(SH.$('#n', root).value, SH.$('#em', root).value, SH.$('#pw', root).value)
          .then(function (r) {
            if (r && r.needsConfirm) {
              SH.$('#f', root).outerHTML = '<div class="notice info"><strong>Check your email.</strong> We sent a confirmation link to ' + e(r.email) + '. Click it, then log in.</div>';
              return;
            }
            SH.toast('Welcome to StudentHub PH!'); SH.go('/dashboard');
          }, function (er) { errBox(root, er.message); });
      });
    });

  authPage('/login', 'Log in | StudentHub PH', 'Log in to your StudentHub PH account.',
    '<div class="card"><h1 style="font-size:1.6rem">Log in</h1>' + DEV +
    '<form id="f"><div class="field"><label for="em">Email</label><input id="em" type="email" autocomplete="email" required></div>' +
    '<div class="field"><label for="pw">Password</label><input id="pw" type="password" autocomplete="current-password" required></div>' +
    '<div class="notice" id="err" role="alert" hidden style="background:#fef2f2;border-color:#fecaca;color:#991b1b"></div>' +
    '<button class="btn btn-primary" style="width:100%" type="submit">Log in</button></form>' +
    '<p class="small" style="margin-top:12px"><a href="#/reset">Forgot password?</a> · <a href="#/signup">Create an account</a></p></div>',
    function (root, params) {
      SH.$('#f', root).addEventListener('submit', function (ev) {
        ev.preventDefault(); errBox(root, '');
        SH.auth.logIn(SH.$('#em', root).value, SH.$('#pw', root).value)
          .then(function () { SH.go(params.next && params.next.charAt(0) === '/' ? params.next : '/dashboard'); }, function (er) { errBox(root, er.message); });
      });
    });

  authPage('/reset', 'Reset password | StudentHub PH', 'Reset your StudentHub PH password.',
    '<div class="card"><h1 style="font-size:1.6rem">Reset password</h1><div class="notice" data-local-only><strong>Needs an email service.</strong> Password reset sends a secure link by email, so it only works once an email provider is connected (see README). It is intentionally not simulated in this development build.</div>' +
    '<form id="f"><div class="field"><label for="em">Email</label><input id="em" type="email" required></div><div class="notice" id="err" role="alert" hidden></div><button class="btn btn-primary" style="width:100%" type="submit">Send reset link</button></form>' +
    '<p class="small" style="margin-top:12px"><a href="#/login">Back to log in</a></p></div>',
    function (root) {
      SH.$('#f', root).addEventListener('submit', function (ev) {
        ev.preventDefault(); errBox(root, '');
        SH.auth.resetPassword(SH.$('#em', root).value).then(function () {
          SH.$('#f', root).outerHTML = '<div class="notice info">If an account exists for that email, a reset link is on its way. Check your inbox (and spam).</div>';
        }, function (er) { errBox(root, er.message); });
      });
    });

  SH.addRoute('/new-password', {
    title: 'Set a new password | StudentHub PH', desc: 'Choose a new password.', auth: true,
    render: function (root) {
      root.innerHTML = '<div class="wrap section" style="max-width:460px"><div class="card"><h1 style="font-size:1.6rem">Set a new password</h1><form id="f"><div class="field"><label for="pw">New password <span class="muted">(8+ characters)</span></label><input id="pw" type="password" autocomplete="new-password" required></div><div class="notice" id="err" role="alert" hidden></div><button class="btn btn-primary" style="width:100%" type="submit">Save password</button></form></div></div>';
      SH.$('#f', root).addEventListener('submit', function (ev) {
        ev.preventDefault(); errBox(root, '');
        SH.auth.updatePassword(SH.$('#pw', root).value).then(function () { SH.toast('Password updated'); SH.go('/dashboard'); }, function (er) { errBox(root, er.message); });
      });
    }
  });

  SH.addRoute('/profile', {
    title: 'Your profile | StudentHub PH', desc: 'Edit your StudentHub PH profile.', auth: true,
    render: function (root) {
      var u = SH.auth.user();
      root.innerHTML = '<div class="wrap section" style="max-width:560px"><div class="card"><h1 style="font-size:1.6rem">Your profile</h1><form id="f">' +
        '<div class="field"><label for="n">Name</label><input id="n" value="' + e(u.name) + '" required></div><div class="field"><label>Email</label><input value="' + e(u.email) + '" disabled></div>' +
        '<div class="row c2"><div class="field"><label for="s">School</label><input id="s" value="' + e(u.school) + '"></div><div class="field"><label for="l">Level</label><select id="l">' +
        ['', 'Senior high school', 'College', 'Graduate'].map(function (x) { return '<option' + (x === u.level ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div></div>' +
        '<button class="btn btn-primary" type="submit">Save profile</button></form></div></div>';
      SH.$('#f', root).addEventListener('submit', function (ev) {
        ev.preventDefault(); SH.auth.updateProfile({ name: SH.$('#n', root).value, school: SH.$('#s', root).value, level: SH.$('#l', root).value }); SH.toast('Profile saved');
      });
    }
  });

  /* ---- Dashboard ---- */
  var RECOMMENDED = [ // SAMPLE recommendations – static links to well-known free resources, not personalized yet
    ['APA Style (official)', 'https://apastyle.apa.org/', 'Official guidance for APA 7'],
    ['Purdue OWL', 'https://owl.purdue.edu/', 'Writing and citation help'],
    ['Google Scholar', 'https://scholar.google.com/', 'Search scholarly articles'],
    ['DOAJ', 'https://doaj.org/', 'Directory of open-access journals'],
    ['Khan Academy', 'https://www.khanacademy.org/', 'Free lessons and practice']
  ];

  SH.addRoute('/dashboard', {
    title: 'Dashboard | StudentHub PH', desc: 'Your StudentHub PH dashboard.', auth: true,
    render: function (root) {
      var u = SH.auth.user(), plan = SH.db.get('plan', []), t = SH.today();
      var open = plan.filter(function (i) { return !i.done && i.date && i.date >= t; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; }).slice(0, 5);
      var overdue = plan.filter(function (i) { return !i.done && i.date && i.date < t; }).length;
      var done = plan.filter(function (i) { return i.done; }).length, pct = plan.length ? Math.round(done / plan.length * 100) : 0;
      var saved = SH.saved.list().map(SH.toolById).filter(Boolean), hist = SH.history.list().slice(0, 6);
      root.innerHTML = '<div class="wrap">' + '<div class="page-head"><h1>Welcome back, ' + e(u.name.split(' ')[0]) + '!</h1><p>Here’s what’s happening in your student life.</p></div>' +
        '<div class="grid g2"><div class="card"><h2>Upcoming deadlines</h2>' + (overdue ? '<p><span class="tag warn">' + overdue + ' overdue</span></p>' : '') +
        (open.length ? open.map(function (i) { return '<div class="item"><div><div class="t">' + e(i.title) + '</div><div class="meta">' + e(i.type) + (i.subject ? ' · ' + e(i.subject) : '') + ' · ' + e(i.date) + '</div></div></div>'; }).join('') : '<p class="muted">No upcoming deadlines. <a href="#/study-planner">Add some in the planner</a>.</p>') + '</div>' +
        '<div class="card"><h2>Study progress</h2><div class="big">' + pct + '%</div><div class="bar" style="margin:10px 0"><i style="width:' + pct + '%"></i></div><p class="muted small">' + done + ' of ' + plan.length + ' planner items completed.</p></div>' +
        '<div class="card"><h2>Saved tools</h2>' + (saved.length ? saved.map(function (s) { return '<p><a href="#' + s.route + '">' + s.icon + ' ' + e(s.name) + '</a></p>'; }).join('') : '<p class="muted">Tap the ★ on any tool to pin it here.</p>') + '</div>' +
        '<div class="card"><h2>Recent projects</h2>' + (hist.length ? hist.map(function (h) { return '<p><a href="#' + h.route + '">' + e(h.label) + '</a><br><span class="small muted">' + new Date(h.at).toLocaleDateString() + '</span></p>'; }).join('') : '<p class="muted">Your saved results and exports will show up here.</p>') + '</div>' +
        '<div class="card"><h2>Recommended resources</h2><p class="small muted">Sample list – not yet personalized.</p>' + RECOMMENDED.map(function (r) { return '<p><a href="' + r[1] + '" target="_blank" rel="noopener">' + e(r[0]) + '</a><br><span class="small muted">' + e(r[2]) + '</span></p>'; }).join('') + '</div>' +
        '<div class="card"><h2>Subscription</h2><p>Current plan: <span class="tag ok">' + (u.plan === 'free' ? 'Free' : e(u.plan)) + '</span></p><p class="muted small">Paid plans and billing need a payment gateway integration and are not available yet.</p><a class="btn btn-sm" href="#/pricing">See plans</a></div></div></div>';
    }
  });

  /* ---- Pricing ---- */
  SH.addRoute('/pricing', {
    title: 'Pricing – Free & Student Plus Plans | StudentHub PH', desc: 'StudentHub PH is free to start. Student Plus is ₱99 per month or ₱499 per year for more AI generations, premium templates and an ad-free experience.',
    render: function (root) {
      function plan(name, price, per, items, cls, btn) {
        return '<div class="card plan ' + cls + '"><h2>' + name + '</h2><div class="price">' + price + ' <small>' + per + '</small></div><ul>' + items.map(function (i) { return '<li>' + i + '</li>'; }).join('') + '</ul>' + btn + '</div>';
      }
      var soon = '<button class="btn" style="width:100%" disabled>Coming soon – payments not connected</button>';
      root.innerHTML = '<div class="wrap">' + '<div class="page-head center"><h1>Simple pricing for students</h1><p style="margin:0 auto">Start free. Upgrade only if you want more.</p></div>' +
        '<div class="notice info center">Pricing may change. Paid plans are not yet on sale – checkout requires a payment gateway integration (see README).</div>' +
        '<div class="grid g3">' +
        plan('Free', '₱0', '/month', ['Basic calculators (grade &amp; GPA)', 'Basic study planner', 'Limited AI generations <span class="tag soon">when AI is connected</span>', 'Basic templates', 'Basic citation tools', 'Non-intrusive ads (planned)'], '', '<a class="btn btn-primary" style="width:100%" href="#/signup">Start free</a>') +
        plan('Student Plus', '₱99', '/month', ['Unlimited basic tools', 'More AI generations', 'Premium templates', 'Advanced study planner', 'Saved projects', 'Ad-free experience', 'Advanced CV templates'], 'best', soon) +
        plan('Annual', '₱499', '/year', ['Everything in Student Plus', 'About 58% less than 12 monthly payments (₱1,188)', 'One payment for the whole school year'], '', soon) + '</div>' +
        '<p class="small muted center" style="margin-top:16px">Some listed features (AI generations, premium templates, ads) arrive in later phases; the plan structure is shown so you know where we’re heading.</p></div>';
    }
  });
})();
