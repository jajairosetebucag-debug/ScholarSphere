/* Site configuration.
   Leave both values empty to run in development mode (accounts and data stay in the browser).
   To use Supabase: paste your Project URL and the "anon" / "public" key (Supabase → Settings → API).
   The anon key is designed to be public. NEVER paste the "service_role" key here. */
window.SH_CONFIG = {
  supabaseUrl: '',      // e.g. 'https://abcdxyz.supabase.co'
  supabaseAnonKey: ''   // the long key labelled "anon" / "public"
};
