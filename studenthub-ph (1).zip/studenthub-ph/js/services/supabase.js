/* Supabase adapter – replaces SH.auth and SH.db when js/config.js has a URL + anon key.
   Design: after login we load the user's rows into an in-memory cache, so pages keep using the same
   synchronous SH.db.get/set. Writes go to the cache immediately and are synced to the database in the
   background (debounced). Guests (not logged in) still use localStorage and are carried over at signup. */
(function () {
  'use strict';
  var SH = window.SH, cfg = window.SH_CONFIG || {};
  if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) { SH.backend = 'local'; return; }
  SH.backend = 'supabase';

  var LIB = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
  var client = null, failed = false, session = null, profile = null, cache = {}, pending = {}, timer = null, listeners = [];
  var orig = { get: SH.db.get, set: SH.db.set };
  var GUEST = 'shph:guest:';

  function emit() { listeners.forEach(function (f) { f(); }); }
  function home() { return location.href.split('#')[0].split('?')[0]; }
  function validEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
  function need() { if (!client) throw new Error('Cannot reach the server right now. Please check your connection and refresh.'); }
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src; s.onload = res;
      s.onerror = function () { rej(new Error('library load failed')); }; document.head.appendChild(s);
    });
  }

  /* ---- background sync ---- */
  function schedule(ms) { clearTimeout(timer); timer = setTimeout(flush, ms || 700); }
  function flush() {
    clearTimeout(timer); timer = null;
    if (!session || !client) return Promise.resolve();
    var keys = Object.keys(pending); if (!keys.length) return Promise.resolve();
    var uid = session.user.id, rows = keys.map(function (k) { return { user_id: uid, key: k, value: pending[k], updated_at: new Date().toISOString() }; });
    pending = {};
    return client.from('user_data').upsert(rows, { onConflict: 'user_id,key' }).then(function (r) {
      if (r.error) {
        SH.toast('Could not sync your data – will retry');
        keys.forEach(function (k) { if (!(k in pending)) pending[k] = cache[k]; });
        schedule(5000);
      }
    }, function () { keys.forEach(function (k) { if (!(k in pending)) pending[k] = cache[k]; }); schedule(5000); });
  }
  window.addEventListener('pagehide', function () { flush(); });
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });

  /* move work done as a guest into the account (once), then clear the guest copy */
  function migrateGuest() {
    try {
      Object.keys(localStorage).filter(function (k) { return k.indexOf(GUEST) === 0; }).forEach(function (full) {
        var k = full.slice(GUEST.length);
        if (!(k in cache)) { try { cache[k] = JSON.parse(localStorage.getItem(full)); pending[k] = cache[k]; } catch (e) {} }
        localStorage.removeItem(full);
      });
      if (Object.keys(pending).length) schedule(300);
    } catch (e) {}
  }

  function loadData() {
    if (!session) { cache = {}; profile = null; return Promise.resolve(); }
    var uid = session.user.id;
    return Promise.all([
      client.from('user_data').select('key,value'),
      client.from('profiles').select('name,school,level,plan,role').eq('id', uid).maybeSingle()
    ]).then(function (r) {
      cache = {}; (r[0].data || []).forEach(function (row) { cache[row.key] = row.value; });
      profile = r[1].data || null;
      migrateGuest();
    }).catch(function () { SH.toast('Could not load your saved data. Please refresh.'); });
  }

  /* ---- SH.db overrides: cache when logged in, localStorage when guest ---- */
  SH.db.get = function (k, f) { if (session) return k in cache ? cache[k] : f; return orig.get.call(this, k, f); };
  SH.db.set = function (k, v) { if (session) { cache[k] = v; pending[k] = v; schedule(); return; } orig.set.call(this, k, v); };

  /* ---- SH.auth (same interface as the dev adapter) ---- */
  SH.auth = {
    isMock: false,
    onChange: function (f) { listeners.push(f); },
    user: function () {
      if (!session) return null;
      var m = session.user.user_metadata || {}, p = profile || {}, email = session.user.email || '';
      return { id: session.user.id, name: p.name || m.name || email.split('@')[0], email: email, school: p.school || '', level: p.level || '', plan: p.plan || 'free', role: p.role || 'user' };
    },
    signUp: function (name, email, password) {
      name = String(name || '').trim(); email = String(email || '').trim().toLowerCase();
      if (!name) return Promise.reject(new Error('Please enter your name.'));
      if (!validEmail(email)) return Promise.reject(new Error('Please enter a valid email address.'));
      if (String(password || '').length < 8) return Promise.reject(new Error('Password must be at least 8 characters.'));
      try { need(); } catch (e) { return Promise.reject(e); }
      return client.auth.signUp({ email: email, password: password, options: { data: { name: name }, emailRedirectTo: home() } }).then(function (r) {
        if (r.error) throw new Error(r.error.message);
        if (!r.data.session) return { needsConfirm: true, email: email }; // email confirmation is switched on
        session = r.data.session; return loadData().then(function () { emit(); return SH.auth.user(); });
      });
    },
    logIn: function (email, password) {
      try { need(); } catch (e) { return Promise.reject(e); }
      return client.auth.signInWithPassword({ email: String(email || '').trim().toLowerCase(), password: password }).then(function (r) {
        if (r.error) throw new Error(r.error.message === 'Invalid login credentials' ? 'Incorrect email or password.' : r.error.message);
        session = r.data.session; return loadData().then(function () { emit(); return SH.auth.user(); });
      });
    },
    logOut: function () {
      return flush().then(function () { return client && client.auth.signOut(); }).then(function () { session = null; profile = null; cache = {}; pending = {}; emit(); });
    },
    updateProfile: function (patch) {
      if (!session) return Promise.resolve();
      var row = {}; ['name', 'school', 'level'].forEach(function (k) { if (patch[k] != null) row[k] = String(patch[k]).trim(); });
      return client.from('profiles').update(row).eq('id', session.user.id).then(function (r) {
        if (r.error) { SH.toast('Could not save profile'); return; }
        profile = Object.assign({}, profile, row); emit();
      });
    },
    resetPassword: function (email) {
      email = String(email || '').trim().toLowerCase();
      if (!validEmail(email)) return Promise.reject(new Error('Please enter a valid email address.'));
      try { need(); } catch (e) { return Promise.reject(e); }
      return client.auth.resetPasswordForEmail(email, { redirectTo: home() }).then(function (r) { if (r.error) throw new Error(r.error.message); return true; });
    },
    updatePassword: function (password) {
      if (String(password || '').length < 8) return Promise.reject(new Error('Password must be at least 8 characters.'));
      try { need(); } catch (e) { return Promise.reject(e); }
      return client.auth.updateUser({ password: password }).then(function (r) { if (r.error) throw new Error(r.error.message); return true; });
    }
  };

  /* ---- start-up: app.js waits for SH.ready before the first render ---- */
  SH.ready = Promise.resolve(window.supabase ? null : loadScript(LIB)).then(function () {
    client = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { flowType: 'pkce', persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
    return client.auth.getSession();
  }).then(function (r) {
    session = r.data && r.data.session ? r.data.session : null;
    client.auth.onAuthStateChange(function (event, s) {
      // run outside the callback: calling Supabase inside it can deadlock
      setTimeout(function () {
        if (event === 'SIGNED_OUT') { session = null; profile = null; cache = {}; emit(); }
        else if (event === 'TOKEN_REFRESHED' && s) { session = s; }
        else if (event === 'PASSWORD_RECOVERY' && s) { session = s; loadData().then(function () { emit(); SH.go('/new-password'); }); }
        else if (event === 'SIGNED_IN' && s && (!session || session.user.id !== s.user.id)) { session = s; loadData().then(function () { emit(); if (SH.render) SH.render(); }); }
      }, 0);
    });
    return loadData();
  }).catch(function (e) {
    failed = true; client = null;
    SH.toast('Could not connect to the server. Working offline as a guest.');
  });
})();
