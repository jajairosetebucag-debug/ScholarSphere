# StudentHub PH — Phase 1 MVP

"Everything Students Need. In One Place."

A mobile-first, no-build web app. Open `index.html` in a browser (or serve the folder with any static server, e.g. `npx serve .`).

## What works today (Phase 1)

| Feature | Status |
|---|---|
| Homepage + global search (name/keyword scoring) | Working |
| Grade Calculator (weights, current grade, required score for a target grade) | Working |
| GPA Calculator (units-weighted; PH 1.00–5.00 sample scale, 4.0 scale, custom scale) | Working |
| APA 7 Citation Generator (book, journal, website, report, video; DOI; multiple authors; copy; saved reference list) | Working |
| Study Planner (subjects, exams, assignments, study sessions, complete, list + calendar) | Working |
| Reviewer / Flashcards (manual decks, study mode, **rule-based** generation from pasted notes) | Working (not AI) |
| CV Builder (3 templates, live preview, PDF via browser "Save as PDF") | Working |
| Accounts, profile, dashboard | Working with a **dev-only local adapter** (see below) |
| Pricing page | Working (display only) |
| Privacy / Terms / Cookies / Disclaimer / Contact / Report an issue | **Draft templates** – needs legal review |
| Phase 2/3 tools (scholarships, internships, thesis, etc.) | Honest "coming soon" pages |

## Connect Supabase (accounts + saved data across devices)

1. Create a project at supabase.com (pick a region near the Philippines, e.g. Singapore).
2. **SQL Editor → New query**: paste all of `supabase/schema.sql` and **Run**. This creates the tables and the security rules (Row Level Security) so each student only sees their own data, and blocks students from giving themselves a paid plan or admin role.
3. **Settings → API**: copy the **Project URL** and the **anon / public** key into `js/config.js`. Never use the `service_role` key in the site.
4. **Authentication → URL Configuration**: set the Site URL to your deployed address (and add it to Redirect URLs). Login-confirmation and password-reset links return there.
5. Deploy the folder (Netlify / Cloudflare Pages / GitHub Pages) and sign up on your own site.
6. Make yourself admin: in the SQL Editor run `update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');`

Leave `js/config.js` empty and the site runs in development mode (browser-only accounts). Supabase's built-in email sender is rate-limited; before launch, connect your own SMTP provider under Authentication → SMTP Settings.
Tested against a stand-in client, not a live Supabase project: do a real signup / login / reset on your project before announcing it.

## Integration requirements (nothing below is faked)

| Need | Where it plugs in | Notes |
|---|---|---|
| **Authentication** | `js/services/auth.js` (dev) / `js/services/supabase.js` | Dev adapter stores accounts in browser localStorage – NOT secure. Fill `js/config.js` to switch to Supabase Auth. |
| **Database** | `SH.db` in `js/core.js` / `js/services/supabase.js` | Supabase adapter included (cache + background sync). Pages only use `SH.db.get/set`. |
| **Email service** | Supabase Auth | Verification and reset emails work once Supabase is connected; use your own SMTP for production volume. |
| **Payments** | Pricing page, dashboard | Needs a gateway that supports PH payments (e.g. PayMongo, Xendit, Stripe) and server-side subscription handling. Paid buttons are disabled. |
| **AI generation** | `SH.lib.generateFromNotes` in `js/pages/flashcards.js` | Current version is rule-based. Swap for an LLM API call made from a **server** (never put API keys in the browser). Add per-plan usage limits there. |
| **File upload (PDF/Word notes)** | Flashcards page | Needs a document-parsing service; paste text for now. |
| **Scholarship / internship data** | Phase 2 | Must come from verified sources with official links and a "last verified" date. No listings are invented. |
| **Ads / affiliates / analytics** | `SH.track` in `js/core.js` | Not implemented. Add consent (cookie banner) before enabling. |
| **Admin dashboard** | Phase 2 | Needs the backend and roles; not built in Phase 1. |
| **Contact / reports** | `js/pages/static.js` | Placeholder email `hello@studenthub.example` – replace. |

## Architecture

```
index.html
css/styles.css            design tokens + components (mobile-first)
js/core.js                helpers, SH.db storage adapter, history, saved tools, grading scales
js/services/auth.js       auth adapter (swap me)
js/tools.js               tool registry (nav, hubs, search, dashboard all read this)
js/app.js                 hash router, header/footer, per-route <title>/description
js/pages/*.js             one file per feature; each registers routes with SH.addRoute
```

To add a tool: add an entry in `js/tools.js`, create `js/pages/yourtool.js`, add a `<script>` in `index.html`.

## Honest notes

- **Sample data:** the PH grading table and the dashboard "recommended resources" are samples. Schools differ; users can edit the custom scale.
- **SEO:** each route sets its own title and meta description, but this is a client-rendered single page with `#` routes, which search engines index poorly. For real SEO, move to a framework with server/static rendering and real URLs (e.g. Next.js, Astro or SvelteKit) and per-page content. The tool logic in `SH.lib.*` and the service interfaces are portable.
- **Scale:** the front end is static and CDN-friendly. Scaling to thousands of users depends on the backend you connect, not this code.
- **Performance:** no frameworks, no images, system fonts, about 115 KB of unminified JS/CSS in total (far less once minified and gzipped). Run Lighthouse after deployment to confirm Core Web Vitals.
- **Accessibility:** skip link, labels, focus styles, 44px+ touch targets, `aria-live` result regions. A full audit with a screen reader is still recommended.
- **Legal pages** are drafts. Have them reviewed (Data Privacy Act of 2012 / RA 10173) before launch.

## Roadmap

Phase 2: scholarship + internship finders (with verified data), thesis organizer, presentation outline, template library, citation checker, admin dashboard, affiliate system.
Phase 3: AI study assistant, advanced research tools, job marketplace, community, PWA, personalization.
