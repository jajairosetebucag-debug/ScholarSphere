-- StudentHub PH – Supabase schema
-- HOW TO USE: Supabase dashboard → SQL Editor → New query → paste this whole file → Run.
-- Safe to run once on a new project. Row Level Security (RLS) makes sure each student can only see their own data.

-- 1) Profiles: one row per user (created automatically at signup)
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  name       text not null default '',
  school     text not null default '',
  level      text not null default '',
  plan       text not null default 'free' check (plan in ('free','plus','annual')),
  role       text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

-- 2) User data: key/value store for planner items, decks, references, CV, history, etc.
create table if not exists public.user_data (
  user_id    uuid not null references auth.users(id) on delete cascade,
  key        text not null check (char_length(key) <= 64),
  value      jsonb not null check (pg_column_size(value) < 1000000),
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

alter table public.profiles  enable row level security;
alter table public.user_data enable row level security;

-- Profiles: you can read and edit only your own row (inserts happen via the trigger below)
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select using ((select auth.uid()) = id);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update
  using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

-- User data: full access to your own rows only
drop policy if exists "user_data_own" on public.user_data;
create policy "user_data_own" on public.user_data for all
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- Create a profile automatically when someone signs up
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)));
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Students must NOT be able to give themselves a paid plan or admin role.
-- Changes made from the SQL editor or a server (where auth.uid() is null) are allowed.
create or replace function public.protect_profile_columns()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and (new.plan is distinct from old.plan or new.role is distinct from old.role) then
    raise exception 'plan and role can only be changed by the site owner';
  end if;
  return new;
end; $$;

drop trigger if exists protect_profile_columns on public.profiles;
create trigger protect_profile_columns before update on public.profiles
  for each row execute function public.protect_profile_columns();

-- 3) AFTER you sign up on your own site, make yourself admin (replace the email), run this separately:
-- update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');
